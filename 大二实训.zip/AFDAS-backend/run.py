import random
from turtle import pd
from flask import Flask, request, jsonify, session,make_response
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_session import Session
import pandas as pd
# from flask_script import Manager
# from flask_migrate import Migrate, MigrateCommand
import os
import numpy as np
from utils.faceDetect import *
from datetime import datetime, timedelta
from utils.dataDeal import *
from utils.Status import *
from utils.returnData import *
from mock.generate_data import *
import json


# 创建应用实例
app = Flask(__name__)

# 利用flask_cors设置跨域
CORS(app, supports_credentials=True)

# -------------------------------------app配置-----------------------------------------
app.config.from_object(__name__) # 应用配置

# 读取配置文件
with open('./config/config.json', 'r') as f:
    config = json.load(f)

# 访问配置参数
app_config = config['app']
store_path = config['STORE_PATH']
database_config = config['database']

# 访问app配置参数
# jsonify转变格式的时候不会转变为unicode编码格式，unicode编码格式无法直接看到汉字
json_as_ascii = app_config['JSON_AS_ASCII']
# 指定浏览器渲染的文件类型，和解码格式
jsonify_mimetype = app_config['JSONIFY_MIMETYPE']
# 设置会话存储的时间为30分钟
session_cookie_duration = app_config['SESSION_COOKIE_DURATION']
# 会话加密
app.secret_key = 'hermes011231231'

# 访问数据库配置参数
dialect = database_config['DIALCT']
driver = database_config['DRIVER']
username = database_config['USERNAME']
password = database_config['PASSWORD']
host = database_config['HOST']
port = database_config['PORT']
database = database_config['DATABASE']

# 构建数据库连接字符串
DB_URI = "{}+{}://{}:{}@{}:{}/{}?charset=utf8".format(
    dialect, driver, username, password, host, port, database)

# 设置SQLAlchemy的数据库连接字符串
app.config["SQLALCHEMY_DATABASE_URI"] = DB_URI

# 实例化所需模块
db = SQLAlchemy(app)
# 用于管理数据库迁移
# manager = Manager(app)
# migrate = Migrate(app, db)
# manager.add_command('db', MigrateCommand)

# -------------------------------------数据库表设计-----------------------------------------
class Group(db.Model):
    __tablename__ ="group"
    id = db.Column(db.Integer, autoincrement=True)
    groupName = db.Column(db.String(255),nullable=False, primary_key=True)
    createTime = db.Column(db.DateTime)
    updateTime = db.Column(db.DateTime)
    # 一对多关系
    # 一个组可以有多个学生
    students = db.relationship('Student', backref='group', lazy='dynamic')


# 员工信息表
class Student(db.Model):
    __tablename__ = "student"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255))
    # 学号，不允许相同
    stuId = db.Column(db.String(255),nullable=False,unique=True)
    # stuAccount = db.Column(db.String(255),nullable=False)
    stuPassword = db.Column(db.String(255),nullable=False)
    stuGroup = db.Column(db.String(255), db.ForeignKey('group.groupName'))
    # phone = db.Column(db.String(255),default='')
    # email = db.Column(db.String(255),default='')
    StuStatus = db.Column(db.Integer,default=0) # 0是正常，1是异常
    createTime = db.Column(db.DateTime)
    updateTime = db.Column(db.DateTime)
    isRole = db.Column(db.Integer, default=0) # 0是普通学生，1是管理员
    isDelete = db.Column(db.Integer, default=0) # 0是未删除，1是已删除
    # 一对多关系
    # 一个学生可以有多个考勤记录
    attendances = db.relationship('Attendance', backref='student', lazy='dynamic')
    # 一个学生可以有多个人脸记录
    faceRecords = db.relationship('FaceRecord', backref='student', lazy='dynamic')


# 人脸记录表
class FaceRecord(db.Model):
    __tablename__ = "faceRecord"
    id = db.Column(db.Integer, primary_key=True)
    stuId = db.Column(db.String(255), db.ForeignKey('student.stuId'))
    stuName = db.Column(db.String(255),nullable=False)
    faceEncoding = db.Column(db.Text,nullable=False)
    createTime = db.Column(db.DateTime)
    updateTime = db.Column(db.DateTime)
    isDelete = db.Column(db.Integer, default=0) # 0是未删除，1是已删除


# 考勤表——记录学生的考勤信息
class Attendance(db.Model):
    __tablename__ = "attendance"
    id = db.Column(db.Integer, primary_key=True)
    stuId = db.Column(db.String(255), db.ForeignKey('student.stuId'))
    stuName = db.Column(db.String(255),nullable=False)
    # 0是上班打卡，1是下班打卡
    attendanceType = db.Column(db.Integer)
    # 0是正常，1是迟到，2是早退
    attendanceStatus = db.Column(db.Integer)
    # 0是正常，1是异常
    attendanceTime = db.Column(db.DateTime) 


# 创建数据库
with app.app_context():
    db.create_all()
    
### -------------------------------------路由配置-----------------------------------------
# 写一个路由，用于测试
# @app.route('/test', methods=['GET'])
# def test():
#     return jsonify({'msg': 'Hello World!'})



# 模拟数据生成
@app.route('/mock', methods=['GET'])
def addMockData():
    # 创建组别
    group_names = ['Group1', 'Group2', 'Group3']
    groups = []
    for i,group_name in enumerate(group_names):
        group = Group(id =i+1,groupName=group_name, createTime=datetime.now() - timedelta(days=30), updateTime=datetime.now() - timedelta(days=30))
        db.session.add(group)
        groups.append(group)

    # 创建学生和相应的考勤记录和人脸记录
    start_stu_id = 20210000
    students = []
    attendances = []

    for i in range(50):
        stu_id = str(start_stu_id + i)
        stu_name = f'Student {i+1}'
        group = random.choice(groups)
        password = '12345678'  # 设置学生密码
        student = Student(id = i+1,name=stu_name, stuId=stu_id, stuPassword=password, stuGroup=group.groupName,
                          createTime=datetime.now() - timedelta(days=30), updateTime=datetime.now() - timedelta(days=30))
        db.session.add(student)
        students.append(student)

        # 创建考勤记录
        # 获取本周一的日期，零时零分零秒
        attendance_time = datetime.now() - timedelta(days=datetime.now().weekday())
        # 零时零分零秒
        attendance_time = attendance_time.replace(hour=0, minute=0, second=0, microsecond=0)
        
        for _ in range(5):  # 创建每个学生一周的考勤记录，每天上午和下午各一次
            attendance_time_am_start = attendance_time + timedelta(hours=8, minutes=0)
            attendance_time_am_end = attendance_time + timedelta(hours=9, minutes=30)
            attendance_time_pm_start = attendance_time + timedelta(hours=17, minutes=0)
            attendance_time_pm_end = attendance_time + timedelta(hours=18, minutes=30)

            # 上午考勤记录
            attendance_time_am = random_datetime(attendance_time_am_start, attendance_time_am_end)
            # print(attendance_time_am)
            attendance_am_type, attendance_am_status = calculate_attendance_type_status(attendance_time_am)

            attendance_am = Attendance(stuId=stu_id, stuName=stu_name, attendanceType=attendance_am_type,
                                       attendanceStatus=attendance_am_status, attendanceTime=attendance_time_am)
            db.session.add(attendance_am)
            attendances.append(attendance_am)

            # 下午考勤记录
            attendance_time_pm = random_datetime(attendance_time_pm_start, attendance_time_pm_end)
            # print(attendance_time_pm)
            attendance_pm_type, attendance_pm_status = calculate_attendance_type_status(attendance_time_pm)

            attendance_pm = Attendance(stuId=stu_id, stuName=stu_name, attendanceType=attendance_pm_type,
                                       attendanceStatus=attendance_pm_status, attendanceTime=attendance_time_pm)
        
            db.session.add(attendance_pm)
            attendances.append(attendance_pm)

            # 更新下一天的日期
            attendance_time += timedelta(days=1)
    
    # 创建管理员，isRole==1
    admin = Student(id = 51,name='admin', stuId = '10001',stuPassword='cquadmin', stuGroup = "Group1",isRole=1, createTime=datetime.now() - timedelta(days=30), updateTime=datetime.now() - timedelta(days=30))
    db.session.add(admin)
    # 提交事务
    db.session.commit()

    # 关闭会话
    db.session.close()

    return 'Mock data added successfully'



@app.route('/uploadStudent', methods=['POST'])
def upload_student():
    if request.method == 'POST':
        try:
            file = request.files['file']
            df = pd.read_excel(file)  # 读取上传的XLSX文件

            for _, row in df.iterrows():
                group_name = row['Group']
                group = Group.query.filter_by(groupName=group_name).first()

                if not group:
                    group = Group(groupName=group_name)
                    db.session.add(group)
                    db.session.commit()
                # id 为学生数据库最大id+1
                student = Student(
                    name=row['Name'],
                    stuId=row['Student ID'],
                    stuPassword='12345678',
                    stuGroup=group.groupName,
                    # 需要减去8个小时
                    createTime=datetime.now() - timedelta(hours=8),
                    updateTime=datetime.now() - timedelta(hours=8)
                )
                db.session.add(student)
                db.session.commit()
            returnData = ReturnData(status=StatusCode.UPDATE_STUDENT_SUCCESS.value, msg='学生信息上传成功', data={})
            return jsonify(returnData.__dict__)
        except Exception as e:
            print("文件上传处理错误：",e)
            returnData = ReturnData(status=StatusCode.UPDATE_STUDENT_FAIL.value, msg='学生信息上传失败', data={})
            return jsonify(returnData.__dict__)
    

# 检测session是否存在
@app.route('/api/checkSession', methods=['GET'])
def check_session():
    # 在这里编写检查会话状态的逻辑
    # if session.get('student'):
    #     stu_data = session.get('student')
    #     stu_data = infoDesensitization(stu_data)
    #     returnData = ReturnData(status=StatusCode.ALREADY_LOGIN.value, msg='已经登录', data=stu_data)
    #     return jsonify(returnData.__dict__)
    # else:
    #     returnData = ReturnData(status=StatusCode.NOT_LOGIN.value, msg='未登录', data={})
    #     return jsonify(returnData.__dict__)
    if request.method == "GET":
        try:
            studentData = session.get('student')
            print("Session：",studentData)

            if studentData:
                returnData = ReturnData(status=StatusCode.ALREADY_LOGIN.value, msg='账号已登录', data=studentData)
                return jsonify(returnData.__dict__)
            else:
                returnData = ReturnData(status=StatusCode.NOT_LOGIN.value, msg='账号未登录', data={})
                return jsonify(returnData.__dict__)
        except Exception as e:
            print(e)
            returnData = ReturnData(status=StatusCode.NOT_LOGIN.value, msg='账号未登录', data={})
            return jsonify(returnData.__dict__)




# 登录接口
@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        try:
            # 获取前端传来的数据    
            data = request.get_json()
            print(data)
            stuId = data.get('stuId')
            password = data.get('password')
            # print(stuId, password)
            # 查询数据库
            student = Student.query.filter_by(stuId=stuId).first()
            # 存在且 idDelete 为 0且 Status 为 0
            if student and student.isDelete == 0:
                if student.StuStatus != 0:
                    returnData = ReturnData(status=StatusCode.LOGIN_FAIL.value, msg='账号已被禁用', data={})
                    return jsonify(returnData.__dict__)
                if student.stuPassword == password:
                    # 脱敏处理
                    return_data = infoDesensitization(student)
                    # 将用户信息存入cookie
                    session['student'] = return_data
                    returnData = ReturnData(status=StatusCode.LOGIN_SUCCESS.value, msg='登录成功', data=return_data)
                    return jsonify(returnData.__dict__)
                else:
                    returnData = ReturnData(status=StatusCode.LOGIN_FAIL.value, msg='密码错误', data={})
                    return jsonify(returnData.__dict__)
            else:
                returnData = ReturnData(status=StatusCode.LOGIN_FAIL.value, msg='用户不存在', data={})
                return jsonify(returnData.__dict__)
        except Exception as e:
            print(e)
            returnData = ReturnData(status=StatusCode.LOGIN_FAIL.value, msg='登录失败', data={})
            return jsonify(returnData.__dict__)

# 注销用户
@app.route('/logout', methods=['GET'])
def logout():
    # 清除session
    session.clear()
    returnData = ReturnData(status=StatusCode.LOGOUT_SUCCESS.value, msg='注销成功', data={})
    print("注销成功")
    return jsonify(returnData.__dict__)


## 学生界面部分-----------------------------------------------------------------------------------

# 人脸识别
@app.route('/student/detect', methods=['GET',"POST"])
def detect():
    
    if request.method == 'POST':
        try:
            
            # 检查facerecord里面是否有该学生的记录
            studentData = session.get('student')
            print("Session：",studentData)
            faceRecord = FaceRecord.query.filter_by(stuId=studentData["stuId"]).first()
            if faceRecord:
                pass
            else:
                returnData = ReturnData(status=StatusCode.DETECT_FAIL.value, msg='请先录入人脸', data=studentData)
                return jsonify(returnData.__dict__)

            print("开始接受图片")
            images = get_upload_files(request.files)
            # print(images)
            # 识别
            print("开始识别")
            # print("当前识别图片：",images[0].shape)
            # 获得学号
            studentData = session.get('student')
            print("Session：",studentData)
            stuId = studentData['stuId']
            result = detect_faces(photos=images,stuId=stuId)
            print("当前识别结果：",result)
            # 添加数据库
            # print("开始添加数据库")
            # 根据时间判断是上班打卡还是下班打卡
            # print("当前时间：",datetime.now().hour)
            attendanceType, attendanceStatus = timeJudge()
            attendance = Attendance(stuId=stuId,
                                    stuName = studentData['name'],
                                    attendanceType = attendanceType,
                                    # 中国北京时间
                                    attendanceTime = datetime.now(),
                                    attendanceStatus = attendanceStatus)
            db.session.add(attendance)
            db.session.commit()
            data = {
                "result": result[0],
                'attendanceType': attendanceType,
                'attendanceStatus': attendanceStatus
            }
            returnData = ReturnData(status=StatusCode.DETECT_SUCCESS.value, msg='识别成功', data=data)
            return jsonify(returnData.__dict__)
        except Exception as e:
            print("识别阶段出现错误：",e)
            returnData = ReturnData(status=StatusCode.DETECT_FAIL.value, msg='识别失败', data={})
            return jsonify(returnData.__dict__)

# 人脸重新上传录入
@app.route('/student/upload', methods=['GET',"POST"])
def upload():
    if request.method == 'POST':
        try:
            print("开始接受图片")
            # 获取上传的图像文件
            images = get_upload_files(request.files)
            # 识别
            # print("开始录入")
            # 获取名字
            studentData = session.get('student')
            print("Session：",studentData)
            name = studentData['name']
            # print("name:",name ,"\n" ,"images:",images)
            # 获得学号
            stuId= studentData['stuId']
            print("stuId:",stuId,"\n","name:",name,"\n")
            result = add_faces(photos=images,stuId=stuId,name=name)
            if result:
                print("录入成功")
                # 更新数据库
                facerecord = FaceRecord.query.filter_by(stuId=stuId).first()
                if facerecord:
                    # 更新数据库
                    facerecord.updateTime = datetime.now()
                    db.session.commit()
                else:
                    # 如果原先没有人脸信息，就添加一条
                    facerecord = FaceRecord(stuId=stuId,
                                            stuName=name,
                                            faceEncoding=f"feature_{stuId}.pkl",
                                            createTime=datetime.now(),
                                            updateTime=datetime.now())
                    db.session.add(facerecord)
                    db.session.commit()
                
                returnData = ReturnData(status=StatusCode.UPLOAD_SUCCESS.value, msg='录入成功', data={})
                return jsonify(returnData.__dict__)
            
            else:
                print("录入失败")
                returnData = ReturnData(status=StatusCode.UPLOAD_FAIL.value, msg='录入失败', data={})
                return jsonify(returnData.__dict__)
        except Exception as e:
            print("录入阶段出现错误：",e)
            returnData = ReturnData(status=StatusCode.UPLOAD_FAIL.value, msg='录入失败', data={})
            return jsonify(returnData.__dict__)

"""
data 
- faceRecord
- information
- attendances
"""
@app.route('/student/information', methods=['GET',"POST"])
def attendancesSingle():
    if request.method == 'GET':
        try:
            # global STUDENT
            # if STUDENT == {}:
            #     returnData = ReturnData(status=StatusCode.NOT_LOGIN.value, msg='未登录', data={})
            #     return jsonify(returnData.__dict__)
            # 获取前端传来的数据    
            #data = request.get_json()
            #stuId = data.get('stuId')
            studentData = session.get('student')
            print("Session：",studentData)
            stuId = studentData['stuId']
            data = {}
            # print(stuId)
            # 查询出勤记录
            attendances = Attendance.query.filter_by(stuId=stuId).all()
            # print(attendances)
            # 将学生信息转化为字典
            attendancesInform = query_results_to_dict(attendances)
            # 查询人脸记录信息
            faceRecord = FaceRecord.query.filter_by(stuId=stuId).all()
            if faceRecord:
                faceRecord = query_results_to_dict(faceRecord)
            else:
                faceRecord = [{}]
            data["faceRecord"] = faceRecord
            data['information'] = studentData
            data['attendances'] = attendancesInform
            returnData = ReturnData(status=StatusCode.GET_INFORMATION_SUCCESS.value, msg='获取學生信息成功', data=data)
            return jsonify(returnData.__dict__)
        except Exception as e:
            print(e)
            returnData = ReturnData(status=StatusCode.GET_INFORMATION_FAIL.value, msg='获取學生信息失败', data={})
            return jsonify(returnData.__dict__)


# 学生密码更新
@app.route('/student/password', methods=['GET',"POST"])
def passwordUpdate():
    if request.method == 'POST':
        try:
            # 获取前端传来的数据    
            data = request.get_json()
            stuId = data.get('stuId')
            oldPassword = data.get('oldPassword')
            newPassword = data.get('newPassword')
            # 查询数据库
            student = Student.query.filter_by(stuId=stuId).first()
            # print(student)
            # 判断密码是否正确
            if student.stuPassword == oldPassword:
                # 更新密码
                student.stuPassword = newPassword
                db.session.commit()
                returnData = ReturnData(status=StatusCode.UPDATE_STUDENT_SUCCESS.value, msg='密码更新成功', data={})
                return jsonify(returnData.__dict__)
            else:
                returnData = ReturnData(status=StatusCode.UPDATE_STUDENT_FAIL.value, msg='密码错误', data={})
                return jsonify(returnData.__dict__)
        except Exception as e:
            print(e)
            returnData = ReturnData(status=StatusCode.UPDATE_STUDENT_FAIL.value, msg='密码更新失败', data={})
            return jsonify(returnData.__dict__)


## 管理员部分-----------------------------------------------------------------------------------
# 将学生信息返回给管理员
"""
data
- num: 学生总人数
- students: 学生信息
- attendances: 学生出勤信息
- groups: 学生分组信息
"""
@app.route('/admin/information', methods=['GET',"POST"])
def studentInformation():
    if request.method == 'GET':
        try:
            # global STUDENT
            # # 如果为空，则说明未登录
            # if STUDENT == {}:
            #     returnData = ReturnData(status=StatusCode.NOT_LOGIN.value, msg='未登录', data={})
            #     return jsonify(returnData.__dict__)
            data={}

            """
             data["num"]：获取学生总人数
            """
            num = Student.query.count()
            data['num'] = num

            """
             data["students"]：获取所有学生信息
            """
            students = Student.query.all()
            # print(students)
            # 将学生信息转化为字典
            studentsInform = student_info_deal(students)
            # print(studentsGroup)
            # 将学生信息返回给管理员
            data['students'] = studentsInform
            """
             data["groups"]：获取所有学生信息
            """
            groups = Group.query.all()
            # print(groups)
            # 把groups转化为数组
            groups = group_info_deal(groups)
            # 计算每个组isRole==0和isDelete==0的学生人数
            for group in groups:
                # 计算每个组isRole==0和isDelete==0的学生人数
                group['groupNum'] = Student.query.filter_by(stuGroup=group['groupName'],isRole=0,isDelete=0).count()
            data['groups'] = groups
            """
             data["attendances"]：获取所有学生考勤信息
            """
            # 得到所有isDelete==0的学生考勤信息
            attendances = Attendance.query.filter_by().all()
            # print(attendances)
            # 将学生信息转化为字典
            attendancesInform = query_results_to_dict(attendances)
            # print(attendancesInform)
            # 将学生信息返回给管理员
            data['attendances'] = attendancesInform
            # print(data)
            # studentData = session.get('student')
            # print("Session保存：",studentData)
            returnData = ReturnData(status=StatusCode.GET_INFORMATION_SUCCESS.value, msg='获取信息成功', data=data)
            return jsonify(returnData.__dict__)
        except Exception as e:
            print("获取信息失败：",e)
            returnData = ReturnData(status=StatusCode.GET_INFORMATION_FAIL.value, msg='获取信息失败', data={})
            return jsonify(returnData.__dict__)
        
# 学生信息修改
@app.route('/admin/students/update', methods=['GET', 'POST'])
def updateStudents():
    if request.method == "POST":
        try:
            data = request.get_json()

            print(data)
            # 如果学生存在，则修改学生信息
            student = Student.query.filter_by(stuId=data['stuId']).first()
            if student:
                # 修改学生信息
                student.name = data['name']
                student.stuGroup = data['stuGroup']
                student.stuId = data['stuId']
                student.StuStatus = data['stuState']
                
                update_time = datetime.strptime(data['updateTime'], "%Y/%m/%d %H:%M:%S")
                student.updateTime = update_time
                db.session.commit()
            else:
                # 如果学生不存在，则添加学生信息
                student = Student(name=data['name'],
                                  stuPassword="12345678",
                                  stuGroup=data['stuGroup'],
                                  stuId=data['stuId'],
                                  StuStatus=data['stuState'],
                                  createTime=datetime.now(),
                                  updateTime=datetime.now())
                db.session.add(student)
                db.session.commit()

            returnData = ReturnData(status=StatusCode.UPDATE_STUDENT_SUCCESS.value, msg='修改学生信息成功', data={})
            return jsonify(returnData.__dict__)

        except Exception as e:
            print("更新学生信息时发生错误：", e)
            returnData = ReturnData(status=StatusCode.UPDATE_STUDENT_FAIL.value, msg='修改学生信息失败', data={})
            return jsonify(returnData.__dict__)

# 学生信息删除
@app.route('/admin/students/delete', methods=['GET',"POST"])
def deleteStudents():
    if request.method == "POST":
        try:
            try:
                data= request.get_json()[0]
            except:
                data= request.get_json()
            print(data)
            # 如果学生存在，则修改学生信息
            student = Student.query.filter_by(stuId=data['stuId']).first()
            if student:
                # 修改学生信息——逻辑删除
                student.isDelete = 1
                student.updateTime = datetime.now()
                db.session.commit()
                returnData = ReturnData(status=StatusCode.DELETE_STUDENT_SUCCESS.value, msg='删除学生信息成功', data={})
                return jsonify(returnData.__dict__)
            else:
                returnData = ReturnData(status=StatusCode.DELETE_STUDENT_FAIL.value, msg='删除学生信息失败', data={})
                return jsonify(returnData.__dict__)

        except Exception as e:
            print("删除学生信息时发生错误：",e)
            returnData = ReturnData(status=StatusCode.DELETE_STUDENT_FAIL.value, msg='删除学生信息失败', data={})
            return jsonify(returnData.__dict__)


# 组别信息修改
@app.route('/admin/groups/update', methods=['GET', 'POST'])
def updateGroups():
    if request.method == "POST":
        try:
            data = request.get_json()
            print(data)
            # 如果组别存在，则修改组别信息
            group = Group.query.filter_by(groupName=data['groupName']).first()
            if group:
                # 修改组别信息
                group.groupName = data['groupName']
                group.id = data['key']
                group.updateTime = datetime.strptime(data['updateTime'], "%Y/%m/%d %H:%M:%S")
                db.session.commit()
            else:
                # 如果组别不存在，则添加组别信息
                group = Group(groupName=data['groupName'],
                              id=data['key'],
                                  createTime=datetime.now() ,
                                  updateTime=datetime.now())
                db.session.add(group)
                db.session.commit()

            returnData = ReturnData(status=StatusCode.UPDATE_GROUP_SUCCESS.value, msg='修改组别信息成功', data={})
            return jsonify(returnData.__dict__)
        except Exception as e:
            print("更新组别信息时发生错误：", e)
            returnData = ReturnData(status=StatusCode.UPDATE_GROUP_FAIL.value, msg='修改组别信息失败(可能该组别还有学生)', data={})
            return jsonify(returnData.__dict__)
        
# 组别信息删除
@app.route('/admin/groups/delete', methods=['GET',"POST"])
def deleteGroups():
    if request.method == "POST":
        try:
            data= request.get_json()[0]
            print(data)
            # 如果组别存在，则修改组别信息
            group = Group.query.filter_by(groupName=data['groupName']).first()
            if group:
                # 修改组别信息——物理删除
                db.session.delete(group)
                db.session.commit()
                returnData = ReturnData(status=StatusCode.DELETE_GROUP_SUCCESS.value, msg='删除组别信息成功', data={})
                return jsonify(returnData.__dict__)
            else:
                returnData = ReturnData(status=StatusCode.DELETE_GROUP_FAIL.value, msg='删除组别信息失败', data={})
                return jsonify(returnData.__dict__)

        except Exception as e:
            print("删除组别信息时发生错误：",e)
            returnData = ReturnData(status=StatusCode.DELETE_GROUP_FAIL.value, msg='删除组别信息失败', data={})
            return jsonify(returnData.__dict__)


            


if __name__ == '__main__':
    app.run(debug=True,host='127.0.0.1',port=8098)