# 辅助函数：生成随机时间
from datetime import timedelta,datetime
import random


def random_datetime(start, end):
    delta = end - start
    random_seconds = random.randint(0, delta.total_seconds())
    return start + timedelta(seconds=random_seconds)


# 辅助函数：根据时间判断考勤类型和状态
def calculate_attendance_type_status(attendance_time):
    attendance_type = 0 if attendance_time.hour < 12 else 1
    attendance_status = 0  # 默认正常

    # 根据时间调整考勤状态
    if attendance_type == 0:  # 上班打卡
        if attendance_time.time() > datetime.strptime('09:00', '%H:%M').time():
            attendance_status = 1  # 迟到
    else:  # 下班打卡
        if attendance_time.time() < datetime.strptime('17:30', '%H:%M').time():
            attendance_status = 2  # 早退
        elif attendance_time.time() > datetime.strptime('18:00', '%H:%M').time():
            attendance_status = 1  # 迟到

    return attendance_type, attendance_status