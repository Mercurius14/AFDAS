import os
import cv2
import pickle
import numpy as np

# 人脸录入
# input: name: str, photos: list, stuId: str
# output: bool
def add_faces(name,photos,stuId):
    try:
        facedetect=cv2.CascadeClassifier('./static/model/haarcascade_frontalface_default.xml')
        faces_data = []
        i = 0
        for i in range(len(photos)):
            frame = photos[i]
            # 转换为灰度图像
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # 人脸检测
            faces = facedetect.detectMultiScale(gray, 1.3, 5)
            # 人脸框图位置
            for (x, y, w, h) in faces:
                crop_img = frame[y:y+h, x:x+w, :]
                resized_img = cv2.resize(crop_img, (50, 50))
                if len(faces_data) <=20:
                    faces_data.append(resized_img)
            if len(faces_data) == 20:
                break

        # 转化为numpy数组特征数据
        faces_data = np.asarray(faces_data)
        faces_data = faces_data.reshape(len(faces_data), -1)
        # 保存特征名字
        # 如果文件夹不存在，则创建文件夹
        if not os.path.exists('./static/data/features/'):
            os.makedirs('./static/data/features/')
        if not os.path.exists('./static/data/names/'):
            os.makedirs('./static/data/names/')

        names = [name] * len(faces_data)
        with open(f'./static/data/names/name_{stuId}.pkl', 'wb') as f:
                pickle.dump(names, f)

        # 保存特征数据
        with open(f'./static/data/features/feature_{stuId}.pkl', 'wb') as f:
            pickle.dump(faces_data, f)
        return True
    except Exception as e:
        print("添加人脸失败",e)
        return False

# 识别人脸
# input: photos: list, stuId: str
# output: attendance: list
def detect_faces(photos,stuId):
    try:
        from sklearn.neighbors import KNeighborsClassifier
        import cv2
        import pickle
        import numpy as np

        from datetime import datetime
        attendance=[]
        facedetect = cv2.CascadeClassifier('./static/model/haarcascade_frontalface_default.xml')
        # 将./features/下的所有特征数据加载到内存中
        FACES = []
        LABELS = []
        for file in os.listdir('./static/data/features/'):
            with open(f'./static/data/features/{file}', 'rb') as f:
                FACES.append(pickle.load(f))
        for file in os.listdir('./static/data/names/'):
            with open(f'./static/data/names/{file}', 'rb') as f:
                LABELS.append(pickle.load(f))
        FACES = np.concatenate(FACES, axis=0)
        LABELS = np.concatenate(LABELS, axis=0)
        

        print('Shape of Faces matrix --> ', FACES.shape)

        knn = KNeighborsClassifier(n_neighbors=5)
        knn.fit(FACES, LABELS)
        # print("识别中"  + stuId + "的人脸")
        # 打印photos的shape
        # print('Shape of Photos matrix --> ', np.asarray(photos).shape)
        for photo in photos:
            # 打印照片的shape
            gray = cv2.cvtColor(photo, cv2.COLOR_BGR2GRAY)
            faces = facedetect.detectMultiScale(gray, 1.3, 5)
            for (x, y, w, h) in faces:
                crop_img = photo[y:y+h, x:x+w, :]
                resized_img = cv2.resize(crop_img, (50, 50)).flatten().reshape(1, -1)
                output = knn.predict(resized_img)
                attendance.append(str(output[0]))
        return attendance
    except Exception as e:
        print("识别失败",e)
        return "识别失败"

# 摄像头保存照片20张到./static/data下面
def get_faces(num):
    try:
        # 指定保存图像的目录
        save_dir = './static/pictures'
        # 创建保存图像的目录（如果不存在）
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        # 使用默认摄像头
        cap = cv2.VideoCapture(0)
        # 获取并保存20张图像
        for i in range(num):
            # 从摄像头读取图像
            ret, frame = cap.read()
            # 生成图像文件名
            filename = f'image_{i+1}.jpg'
            # 保存图像
            cv2.imwrite(os.path.join(save_dir, filename), frame)
            # 显示保存的文件路径
            print(f'Saved: {os.path.join(save_dir, filename)}')
        # 释放摄像头资源
        print("获取图片完成")
        cap.release()
    except Exception as e:
        print("获取人脸照片失败",e)

def test(num, name):
    print("test")
    # 选择拍摄多少张图片
    get_faces(num)
    # 读取图片
    photos = []
    for i in range(num):
        photos.append(f'./static/pictures/image_{i+1}.jpg')
    add_faces(name,photos)
    # 识别人脸
    result = detect_faces(photos)
    # 找到result里面出现次数最多的
    result = max(result, key=result.count)
    if result == name:
        print("识别成功")
    else:
        print("识别失败")
    
    
    
    
    