class ReturnData:
    def __init__(self, msg, status, data):
        self.msg = msg
        self.status = status
        self.data = data

    def to_dict(self):
        return {
            'msg': self.msg,
            'status': self.status,
            'data': self.data
        }
