from datetime import datetime
import cv2
import numpy as np


### -------------------------------------相关函数处理-----------------------------------------
# 信息脱敏——1——员工部分
# input: student: Student
# output: return_student: dict
def infoDesensitization(student):
    # 返回给前端的学生信息
    try:
        return_student = {}
        return_student['stuId'] = student.stuId
        return_student['name'] = student.name
        return_student['stuGroup'] = student.stuGroup
        return_student['isRole'] = student.isRole
        return return_student    
    except Exception as e:
        print("脱敏错误：",e)
        return {}
    
# 信息脱敏——2——数据查询部分
# input: student: Student
# output: return_student: dict
def infoDesensitization2(student):
    # 返回给前端的学生信息
    try:
        return_student = {}
        return_student['id'] = student['id']
        return_student['stuId'] = student['stuId']
        return_student['name'] = student['name']
        return_student['stuGroup'] = student['stuGroup']
        return_student['stuState'] = student['StuStatus']
        return_student['createTime'] = student['createTime']
        return_student['updateTime'] = student['updateTime']

        return return_student    
    except Exception as e:
        print("脱敏错误：",e)
        return {}

# 前端图片处理
# input: files: request.files
# output: images: list
def get_upload_files(files):
    images = []
    try:
        for i in range(len(files)):
            image_key = 'image{}'.format(i)
            if image_key in files:
                file = files[image_key]
                # 进行解码,二进制文件数据解码为图像格式
                image = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_COLOR)
                images.append(image)
                #secure_filename 用于对上传的文件名进行处理，以确保文件名的安全性，并将其作为保存文件的名称
                # filename = secure_filename(file.filename)
                # file_path = os.path.join('./static/pictures', filename)
                # file.save(file_path)
                # images.append(file_path)
        return images
    except Exception as e:
        print("前端图片处理错误：",e)
        return []


# 打卡时间判断
# input: None
# output: attendanceType: int ,    0是上班打卡，1是下班打卡
#         attendanceStatus: int    0是正常，1是迟到，2是早退
def timeJudge():
    # 判断当地中国时间

    if datetime.now().hour < 12:
        attendanceType = 0
    else:
        attendanceType = 1
    # 上午8:30~9:00算正常，下午17:30~18:00算正常
    if attendanceType == 0:
        if datetime.now().hour == 8 and datetime.now().minute < 30:
            attendanceStatus = 2
        elif datetime.now().hour < 8:
            attendanceStatus = 2
        elif datetime.now().hour == 9 and datetime.now().minute > 0:
            attendanceStatus = 1
        elif datetime.now().hour > 9 and datetime.now().hour < 12:
            attendanceStatus = 1
        else:
            attendanceStatus = 0
    else:
        if datetime.now().hour == 17 and datetime.now().minute < 30:
            attendanceStatus = 2
        elif datetime.now().hour < 17 and datetime.now().hour > 12:
            attendanceStatus = 2
        elif datetime.now().hour == 18 and datetime.now().minute > 0:
            attendanceStatus = 1
        elif datetime.now().hour > 18:
            attendanceStatus = 1
        else:
            attendanceStatus = 0
    return attendanceType, attendanceStatus

# 数据库转化为字典
# input: results: list
# output: result_list: list
def query_results_to_dict(results):
    result_list = []

    for result in results:
        result_dict = result.__dict__
        result_list.append({key: result_dict[key] for key in result_dict if not key.startswith('_')})

    return result_list


# 学生信息处理
# input: student: Student
# output: return_student: dict
def student_info_deal(student):
    students = query_results_to_dict(student)
    # print(students)
    # 而且只要isRole==0和isDelete==0的学生
    studentsInform = []
    for student in students:
        if student['isRole'] == 0 and student['isDelete'] == 0:
            studentsInform.append(infoDesensitization2(student))

    return studentsInform
# 组别信息处理
# input: group: Group
# output: return_group: list
def group_info_deal(group):
     # 把groups转化为数组
    groups = query_results_to_dict(group)
    for i,group in enumerate(groups):
        group['id'] =i+1

    return groups