from enum import Enum

# 枚举类定义返回状态码
class StatusCode(Enum):
    # 登录失败
    LOGIN_FAIL = 1101
    # 登录成功
    LOGIN_SUCCESS = 1001
    # 注册失败
    REGISTER_FAIL = 1102
    # 注册成功
    REGISTER_SUCCESS = 1002
    # 未登录
    NOT_LOGIN = 1103
    # 未注册
    NOT_REGISTER = 1104
    # 已登录
    ALREADY_LOGIN = 1003
    # 识别成功
    DETECT_SUCCESS = 1004
    # 识别失败
    DETECT_FAIL = 1105
    # 识别错误
    DETECT_ERROR = 1106
    # 录入成功
    UPLOAD_SUCCESS = 1005
    # 录入失败
    UPLOAD_FAIL = 1107
    # 未录入
    NOT_ADD = 1108
    # 得到信息成功
    GET_INFORMATION_SUCCESS = 1006
    # 得到信息失败
    GET_INFORMATION_FAIL = 1109
    # 更新学生信息成功
    UPDATE_STUDENT_SUCCESS = 1007
    # 更新学生信息失败
    UPDATE_STUDENT_FAIL = 1110
    # 删除学生信息成功
    DELETE_STUDENT_SUCCESS = 1008
    # 删除学生信息失败
    DELETE_STUDENT_FAIL = 1111
    # 更新组别信息成功
    UPDATE_GROUP_SUCCESS = 1009
    # 更新组别信息失败
    UPDATE_GROUP_FAIL = 1112
    # 删除组别信息成功
    DELETE_GROUP_SUCCESS = 1010
    # 删除组别信息失败
    DELETE_GROUP_FAIL = 1113
    # 退出登录成功
    LOGOUT_SUCCESS = 1011
    # 未知错误
    UNKNOWN_ERROR = 1109