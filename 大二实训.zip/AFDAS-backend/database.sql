CREATE TABLE `group` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `groupName` VARCHAR(255) NOT NULL,
  `createTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updateTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE `student` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(255),
  `stuId` VARCHAR(255) NOT NULL UNIQUE,
  `stuPassword` VARCHAR(255) NOT NULL,
  `stuGroup` VARCHAR(255),
  `StuStatus` INT DEFAULT 0,
  `createTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updateTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `isRole` INT DEFAULT 0,
  `isDelete` INT DEFAULT 0,
  FOREIGN KEY (`stuGroup`) REFERENCES `group`(`groupName`)
);

CREATE TABLE `faceRecord` (
  `id` INT PRIMARY KEY,
  `stuId` VARCHAR(255),
  `stuName` VARCHAR(255) NOT NULL,
  `faceEncoding` TEXT NOT NULL,
  `createTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updateTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `isDelete` INT DEFAULT 0,
  FOREIGN KEY (`stuId`) REFERENCES `student`(`stuId`)
);

CREATE TABLE `attendance` (
  `id` INT PRIMARY KEY,
  `stuId` VARCHAR(255),
  `empName` VARCHAR(255) NOT NULL,
  `attendanceType` INT,
  `attendanceStatus` INT,
  `attendanceTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`stuId`) REFERENCES `student`(`stuId`)
);
