// 脚注
import { Layout } from 'antd';
import { GithubOutlined } from '@ant-design/icons';
const { Footer } = Layout;

const Foot = () => {
    return (
        <Layout>
            {/* 其他布局内容 */}
            <Footer style={{ textAlign: 'center', position: 'fixed', bottom: 0, width: '100%' ,height: '75px'}}>
                <div>
                    ©2023 YujianHuang
                </div>
                <div>
                    <a href="https://github.com/Mercurius14">
                        <GithubOutlined />Github
                    </a>
                </div>
            </Footer>
        </Layout>
    );
};

export default Foot;
