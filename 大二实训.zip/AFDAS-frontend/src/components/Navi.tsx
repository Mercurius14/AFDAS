// 顶部导航页
import React from 'react';
import {Layout, Menu, Dropdown, Typography, message} from 'antd';
import { UserOutlined, LogoutOutlined, SmileOutlined } from '@ant-design/icons';

import {history, useLocation} from '@@/exports';
import {Logout} from "@/services/api";
const { Header } = Layout;
const { Text } = Typography;

const Navi: React.FC = () => {
    const location = useLocation();
    const params = new URLSearchParams(location.search);
    const name = params.get('name');
    const handleLogout = () => {
        // 执行退出登录逻辑
        Logout().then((res) => {
            const informationData = res?.data;
            // console.log(informationData);
            if (informationData?.status === 1011) {
                message.success('退出登录成功');
                history.push("/login");
            } else {
                message.error('退出登录失败');
            }
        }).catch((err) => {
            console.log(err);
            message.error('退出登录失败');
        });
    };

    const menu = (
        <Menu>
            <Menu.Item key="logout" onClick={handleLogout} icon={<LogoutOutlined />}>
                退出登录
            </Menu.Item>
        </Menu>
    );

    return (
        <Header style={{ margin: '2px', background: 'white', borderBottom: '1px solid #ccc' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                    <Text strong>AI人脸打卡系统</Text>
                </div>
                <div>
                    <Dropdown overlay={menu} trigger={['hover']}>
            <span>
              <UserOutlined />
              <Text strong>{name}</Text>
            </span>
                    </Dropdown>
                </div>
            </div>
        </Header>
    );
};

export default Navi;
