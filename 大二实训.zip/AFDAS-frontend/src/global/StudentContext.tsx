// 全局变量上下文

import React, { createContext, useState } from 'react';

// 学生sesstion信息存储
type StudentContextType = {
    studentData: any;
    setStudentData: (data: any) => void;
};

// 学生信息上下文提供者的属性类型

interface StudentContextProviderProps {
    children: React.ReactNode;
}
// 创建全局上下文，并提供初始值

export const StudentContext = createContext<StudentContextType>({
    studentData: null,
    setStudentData: () => {},
});

// 全局上下文提供者组件
export const StudentContextProvider: React.FC<StudentContextProviderProps> = ({ children }) => {
    const [studentData, setStudentData] = useState(null);

    return (
        <StudentContext.Provider value={{ studentData, setStudentData }}>
            {children}
        </StudentContext.Provider>
    );
};
