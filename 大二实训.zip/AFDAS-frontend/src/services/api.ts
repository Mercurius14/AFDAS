// 用于存放api接口的文件
import axios from "axios";

// 登录的api
export async function handleLoginFormSubmit(values: any){
    try {
        console.log(values)
        // 发起网络请求将表单数据发送给后端
        return await axios.post('http://localhost:8098/login', values,{ withCredentials: true });
    } catch (error) {
        // 处理错误情况
        console.error(error);
        // 显示错误信息
        // 示例：message.error('登录失败，请重试！');
    }
}

// 注销的api
export async function Logout(){
    try {
        // 发起网络请求将表单数据发送给后端
        return await axios.get('http://localhost:8098/logout',{ withCredentials: true });
    } catch (error) {
        // 处理错误情况
        console.error(error);
        // 显示错误信息
        // 示例：message.error('登录失败，请重试！');
    }
}

// 获取session
export async function getSesstion(){
    try {
        // 发起网络请求将表单数据发送给后端
        return await axios.get('http://localhost:8098/api/checkSession',{ withCredentials: true });
    }
    catch (error) {
        // 处理错误情况
        console.error(error);
        // 显示错误信息
        // 示例：message.error('登录失败，请重试！');
    }
}

// 识别人脸的api
export async function detectFaces(formData: any) {
    try {
        console.log("开始传输")
        const response = await axios.post('http://localhost:8098/student/detect', formData,{ withCredentials: true });
        console.log(response)
        return response.data;
    } catch (error) {
        console.error('Error:', error);
        throw new Error('Face detection failed.');
    }
}
// 录入人脸的api
export async function uploadImages(formData: any) {
    try {
        console.log("开始传输")
        const response = await axios.post('http://localhost:8098/student/upload', formData,{ withCredentials: true });
        const status = response.data.status;
        console.log(response)
        return status === 1005;
    } catch (error) {
        console.error('Error:', error);
        throw new Error('Image upload failed.');
    }
}



export async function studentInformation(){
    try {
        // console.log()
        // 发起网络请求将表单数据发送给后端
        return await axios.get('http://localhost:8098/student/information',{ withCredentials: true });
    } catch (error) {
        // 处理错误情况
        console.error(error);
        // 显示错误信息
        // 示例：message.error('登录失败，请重试！');
    }
}


// 获取学生信息

export async function getStudents() {
    try {
        // 发起网络请求获取学生数据
        const response = await axios.get('http://localhost:8098/admin/information',{ withCredentials: true });
        return response.data; // 返回后端返回的数据
    } catch (error) {
        // 处理错误情况
        console.error(error);
        // 显示错误信息
        // 示例：message.error('获取学生数据失败，请重试！');
    }
}

// 修改学生信息
export async function updateStudent(values: any) {
    try {
        const response = await axios.post('http://localhost:8098/admin/students/update', values,{ withCredentials: true });
        return response.data;
    } catch (error) {
        console.log('保存失败', error);
    }
}
// 删除学生信息
export async function deleteStudent(values: any) {
    try {
        const response = await axios.post('http://localhost:8098/admin/students/delete', values,{ withCredentials: true });
        return response.data;
    } catch (error) {
        console.log('删除失败', error);
    }
}

// 修改学生信息
export async function updateGroup(values: any) {
    try {
        const response = await axios.post('http://localhost:8098/admin/groups/update', values,{ withCredentials: true });
        return response.data;
    } catch (error) {
        console.log('保存失败', error);
    }
}
// 删除学生信息
export async function deleteGroup(values: any) {
    try {
        const response = await axios.post('http://localhost:8098/admin/groups/delete', values,{ withCredentials: true });
        return response.data;
    } catch (error) {
        console.log('删除失败', error);
    }
}

// 修改密码
export async function passwordUpdate(values: any) {
    try {
        const response = await axios.post('http://localhost:8098/student/password', values,{ withCredentials: true });
        return response.data;
    } catch (error) {
        console.log('修改失败', error);
    }
}