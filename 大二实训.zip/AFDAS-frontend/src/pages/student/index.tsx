// 学生端主页
import React from "react";
import FramePage from "@/pages/student/components/FramePage";
import {StudentContextProvider} from "@/global/StudentContext";
import {getSesstion, Logout} from "@/services/api";
import {message} from "antd";
import {history, useLocation} from "@@/exports";

const EmployeePage = () => {
    const location = useLocation();
    const params = new URLSearchParams(location.search);
    const name = params.get('name');
    getSesstion().then((res) => {
        console.log("session保存：",res?.data);
        if (res?.data?.status === 1103 || name != res?.data?.data?.name ){
            // 执行退出登录逻辑
            Logout().then((res) => {
                const informationData = res?.data;
                // console.log(informationData);
                if (informationData?.status === 1011) {
                    history.push("/login");
                }
            })
            // //message.error("登录失败");
            // window.location.href = "/login";    // 重定向到登录页面
        }

    }).catch((err) => {
        console.log("session保存失败：",err);
        message.error("登录失败");
    });
    return (
        <StudentContextProvider>
            <FramePage />
        </StudentContextProvider>
    );
};

export default EmployeePage;
