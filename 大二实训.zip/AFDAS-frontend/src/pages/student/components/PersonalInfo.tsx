// 学生个人信息和修改密码组件
import React, { useState, useContext } from "react";
import { StudentContext } from "@/global/StudentContext";
import { Descriptions, Button, Input, message, Popover } from 'antd';
import {passwordUpdate} from "@/services/api";

const PersonalInfo: React.FC = () => {
    const { studentData, setStudentData } = useContext(StudentContext);
    const [oldPassword, setOldPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [popoverVisible, setPopoverVisible] = useState(false);

    const handlePasswordChange = () => {
        if (newPassword !== confirmPassword) {
            message.error("两次输入的密码不一致");
            return;
        }

        passwordUpdate({
            stuId: studentData.information.stuId,
            oldPassword: oldPassword,
            newPassword: newPassword
        }).then((res) => {
            if (res.status === 1007) {
                message.success(res.msg);
                setPopoverVisible(false);
            } else {
                message.error(res.msg);
            }
        });
    };

    const handlePopoverVisibleChange = (visible: boolean) => {
        setPopoverVisible(visible);
    };

    const content = (
        <div style={{ width: "200px" }}>
            <Input.Password
                placeholder="原密码"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
            />
            <Input.Password
                placeholder="新密码"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                style={{ marginTop: "10px" }}
            />
            <Input.Password
                placeholder="确认密码"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                style={{ marginTop: "10px" }}
            />
            <Button type="primary" onClick={handlePasswordChange} style={{ marginTop: "10px" }}>
                修改密码
            </Button>
        </div>
    );

    return (
        <div>
            <Descriptions
                title="学生信息"
                bordered
                // 不同屏幕下的列数
                column={{ xxl: 4, xl: 3, lg: 3, md: 3, sm: 2, xs: 1 }}
            >
                <Descriptions.Item label="学号">{studentData.information.stuId}</Descriptions.Item>
                <Descriptions.Item label="学生姓名">{studentData.information.name}</Descriptions.Item>
                <Descriptions.Item label="学生组别">{studentData.information.stuGroup}</Descriptions.Item>
            </Descriptions>

            <div style={{ marginTop: "20px" }}>
                <Popover
                    content={content}
                    title="修改密码"
                    visible={popoverVisible}
                    onVisibleChange={handlePopoverVisibleChange}
                    trigger="click"
                    placement="bottom"
                >
                    <span style={{ color: "blue", cursor: "pointer" }}>修改密码</span>
                </Popover>
            </div>
        </div>
    );
}

export default PersonalInfo;
