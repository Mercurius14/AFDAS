// 人脸上传组件
import React, {useState, useRef, useEffect, useContext} from 'react';
import Webcam from 'react-webcam';
import { Button, Modal } from 'antd';
import {uploadImages} from "@/services/api";
import {useLocation} from "@@/exports";
import {dataURItoBlob} from "@/utils/tools";
import {StudentContext} from "@/global/StudentContext";

const UploadFace = () => {
    // 获取url中的参数
    const location = useLocation();
    const params = new URLSearchParams(location.search);
    const name = params.get('name');
    // console.log("姓名",name)
    // 设置摄像头
    const webcamRef = useRef<Webcam>(null);
    // 是否显示摄像头
    const [showWebcam, setShowWebcam] = useState(false);
    // 拍摄的照片
    const [capturedImages, setCapturedImages] = useState<string[]>([]);
    // 是否显示成功的模态框
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    // 是否显示失败的模态框
    const [showErrorModal, setShowErrorModal] = useState(false);

    const handleStartRecognition = () => {
        setShowWebcam(true);
        captureImages();
    };

    // 拍摄照片
    const captureImages = () => {
        // 存储照片的数组
        const images: string[] = [];
        const captureImage = () => {
            if (images.length < 30) {
                const imageSrc = (webcamRef.current as Webcam)?.getScreenshot();
                // console.log(imageSrc)
                if (imageSrc) {
                    // console.log("拍摄一张照片")
                    images.push(imageSrc);
                    setCapturedImages(images);
                    if (images.length === 30) {
                        //console.log("十张照片够了")
                        // 测试
                        // setShowSuccessModal(true);
                        // setShowWebcam(false);
                        // 传给后端
                        processImages(images);

                    } else {
                        setTimeout(captureImage, 20); // 每0.02秒拍摄一张照片
                    }
                }
                else{
                    setTimeout(captureImage, 100); // 每0.1秒拍摄一张照片
                }
            }
        };
        captureImage();
    };


    const processImages = (images: string[]) => {
        // console.log("传给后端的照片",images)
        const formData = new FormData();
        images.forEach((image, index) => {
            const blob = dataURItoBlob(image);
            formData.append('image' + index, blob, 'image' + index + '.jpg');
        });
        // console.log("照片",formData);
        uploadImages(formData)
            .then((success) => {
                if (success) {
                    // 更新录入时间
                    setFaceRecord(new Date().toLocaleString());

                    setShowSuccessModal(true);
                    setShowWebcam(false);
                } else {
                    setShowErrorModal(true);
                    setShowWebcam(false);
                }
            })
            .catch((error) => {
                console.error(error);
                setShowErrorModal(true);
                setShowWebcam(false);
            });
    };


    const handleSuccessModalOk = () => {
        setShowSuccessModal(false);
    };

    const handleErrorModalOk = () => {
        setShowErrorModal(false);
    };

    const {studentData, setStudentData} = useContext(StudentContext);

    // 取出最新的一条打卡记录
    const [faceRecord, setFaceRecord] = useState<any>(null); // lastAttendance是一个对象，包含attendanceTime和attendanceType
    useEffect(() => {
        // 将最新的一条录入记录存入lastAttendance
        if (studentData?.faceRecord) {
            if (studentData.faceRecord.length === 1) {
                setFaceRecord("未录入人脸");
                console.log("未录入人脸")
            } else {
                const time = new Date(studentData.faceRecord[0].updateTime);
                time.setHours(time.getHours() - 8);
                setFaceRecord(time.toLocaleString());
            }
        }
    }, [studentData]);

    return (
        <div>
            <div>
                <h4>
                    上次人脸录入：{faceRecord}
                </h4>
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
                <div style={{ position: 'relative', width: '300px', height: '225px' }}>
                    {showWebcam && (
                        <div
                            style={{
                                position: 'absolute',
                                border: '2px solid #ccc',
                                top: '50%',
                                left: '50%',
                                transform: 'translate(-50%, -50%)',
                                width: '100%',
                                height: '100%',
                            }}
                        >
                            {/* 使用Webcam组件显示摄像头 */}
                            <Webcam
                                ref={webcamRef}
                                mirrored={true}
                                style={{ width: '100%', height: '100%' }}
                            />
                        </div>
                    )}
                    {!showWebcam && (
                        <div
                            style={{
                                position: 'absolute',
                                border: '2px solid #ccc',
                                top: '50%',
                                left: '50%',
                                transform: 'translate(-50%, -50%)',
                                width: '100%',
                                height: '100%',
                                backgroundColor: '#f5f5f5',
                            }}
                        />
                    )}
                    <div
                        style={{
                            position: 'absolute',
                            top: '50%',
                            left: '50%',
                            transform: 'translate(-50%, -50%)',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                        }}
                    >
                        {!showWebcam && <Button onClick={handleStartRecognition}>开始录入</Button>}
                    </div>
                </div>

                <Modal
                    title={`录入成功`}
                    open={showSuccessModal}
                    onOk={handleSuccessModalOk}
                >
                    {/*绿色提醒*/}
                    <p style={{color:"green"}}>{`${name} - 录入成功`}</p>
                </Modal>

                <Modal
                    title={`录入失败`}
                    open={showErrorModal}
                    onOk={handleErrorModalOk}
                >
                    <p style={{color:"red"}}>{`${name} - 录入失败`}</p>
                </Modal>
            </div>
        </div>
    );
};

export default UploadFace;
