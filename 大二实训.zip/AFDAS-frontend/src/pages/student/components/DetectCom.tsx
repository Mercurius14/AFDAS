// 人脸识别组件
import React, {useState, useRef, useContext, useEffect} from 'react';
import Webcam from 'react-webcam';
import {Button, message, Modal} from 'antd';
import {detectFaces, studentInformation, uploadImages} from "@/services/api";
import {history, useLocation} from "@@/exports";
import {dataURItoBlob} from "@/utils/tools";
import {StudentContext} from "@/global/StudentContext";
import {UserOutlined} from "@ant-design/icons";

const DetectCom = () => {
    // 获取url中的参数
    const location = useLocation();
    const params = new URLSearchParams(location.search);
    const name = params.get('name');
    // console.log("姓名",name)
    // 全局变量
    const {studentData, setStudentData} = useContext(StudentContext);

    // 设置摄像头
    const webcamRef = useRef<Webcam>(null);
    // 是否显示摄像头
    const [showWebcam, setShowWebcam] = useState(false);
    // 拍摄的照片
    const [capturedImages, setCapturedImages] = useState<string[]>([]);
    // 是否显示成功的模态框
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    // 是否显示失败的模态框
    const [showErrorModal, setShowErrorModal] = useState(false);
    // 打卡状态
    const [status, setStatus] = useState(0);
    // 打卡时间
    const [time, setTime] = useState(0);
    const handleStartRecognition = () => {
        // 如果两次识别时间间隔小于半个小时，则不允许打卡，lastAttendance?.attendanceTime是上一次的打卡时间
        // if (lastAttendance?.attendanceTime) {
        //     const lastAttendanceTime = new Date(lastAttendance.attendanceTime).getTime();
        //     const now = new Date().getTime();
        //     if (now - lastAttendanceTime < 30 * 60 * 1000) {
        //         message.error("两次识别时间间隔小于半个小时，不允许打卡");
        //         return;
        //     }
        // }
        setShowWebcam(true);
        captureImages();
    };

    const captureImages = () => {
        // 存储照片的数组
        const images: string[] = [];
        const captureImage = () => {
            if (images.length < 30) {
                const imageSrc = (webcamRef.current as Webcam)?.getScreenshot();
                // console.log(imageSrc)
                if (imageSrc) {
                    // console.log("拍摄一张照片")
                    images.push(imageSrc);
                    setCapturedImages(images);
                    if (images.length === 30) {
                        //console.log("十张照片够了")
                        // 测试
                        // setShowSuccessModal(true);
                        // setShowWebcam(false);
                        // 传给后端
                        processImages(images);

                    } else {
                        setTimeout(captureImage, 20); // 每0.02秒拍摄一张照片
                    }
                }
                else{
                    setTimeout(captureImage, 100); // 每0.1秒拍摄一张照片
                }
            }
        };
        captureImage();
    };


    const processImages = (images: string[]) => {
        // console.log("传给后端的照片",images)
        const formData = new FormData();
        images.forEach((image, index) => {
            const blob = dataURItoBlob(image);
            formData.append('image' + index, blob, 'image' + index + '.jpg');
        });
        // console.log("照片",formData);
        detectFaces(formData)
            .then((response) => {
                if (response.status === 1004 && response.data.result === name) {
                    setStatus(response.data.attendanceType)
                    setTime(response.data.attendanceStatus)
                    // 识别成功，全局变量需要更新
                    studentInformation().then((res:any) => {
                        if (res.data.status === 1006) {
                            console.log(res.data);
                            setStudentData(res.data.data);
                        }
                    });
                    setShowSuccessModal(true);
                    setShowWebcam(false);
                } else {
                    message.error(response?.msg)
                    setShowErrorModal(true);
                    setShowWebcam(false);
                }
            })
            .catch((error) => {
                console.error(error);
                setShowErrorModal(true);
                setShowWebcam(false);
            });
    };


    // 辅助函数：将Data URI转换为Blob对象

    const handleSuccessModalOk = () => {
        setShowSuccessModal(false);
    };

    const handleErrorModalOk = () => {
        setShowErrorModal(false);
    };

    // 取出最新的一条打卡记录
    const [lastAttendance, setLastAttendance] = useState<any>(
        {
            attendanceTime: null,
        }
    ); // lastAttendance是一个对象，包含attendanceTime和attendanceType
    // const attendances = studentData.attendances;
    // if (attendances.length > 0) {
    //     const attendanceTime = new Date(studentData.attendances[studentData.attendances.length - 1].attendanceTime);
    //     attendanceTime.setHours(attendanceTime.getHours() - 8);
    //     setLastAttendance({
    //         attendanceTime: attendanceTime,
    //     });
    // }
    useEffect(() => {
        // 将最新的一条打卡记录存入lastAttendance
        if (studentData?.attendances) {
            // 如果有打卡记录
            const attendances = studentData.attendances;
            if (attendances.length > 0) {
                const attendanceTime = new Date(studentData.attendances[studentData.attendances.length - 1].attendanceTime);
                attendanceTime.setHours(attendanceTime.getHours() - 8);

                setLastAttendance({
                    attendanceTime: attendanceTime,
                });
            }
            else {
                setLastAttendance({
                    attendanceTime: null,
                });
            }
        }
    }, [studentData]);

    return (
        <div>
            <h1 style={{ color: '#1890ff' }}>
                正常打卡时间：早上8:30~9:00，下午17:30~18:00
            </h1>
            <h4>
                上次打卡时间：{lastAttendance?.attendanceTime ? lastAttendance.attendanceTime.toLocaleString() : '无'}
            </h4>
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
                <div style={{ position: 'relative', width: '300px', height: '225px' }}>
                    {showWebcam && (
                        <div
                            style={{
                                position: 'absolute',
                                border: '2px solid #ccc',
                                top: '50%',
                                left: '50%',
                                transform: 'translate(-50%, -50%)',
                                width: '100%',
                                height: '100%',
                            }}
                        >
                            {/* 使用Webcam组件显示摄像头 */}
                            <Webcam
                                ref={webcamRef}
                                mirrored={true}
                                style={{ width: '100%', height: '100%' }}
                            />
                        </div>
                    )}
                    {!showWebcam && (
                        <div
                            style={{
                                position: 'absolute',
                                border: '2px solid #ccc',
                                top: '50%',
                                left: '50%',
                                transform: 'translate(-50%, -50%)',
                                width: '100%',
                                height: '100%',
                                backgroundColor: '#f5f5f5',
                            }}
                        />
                    )}
                    <div
                        style={{
                            position: 'absolute',
                            top: '50%',
                            left: '50%',
                            transform: 'translate(-50%, -50%)',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                        }}
                    >
                        {!showWebcam && <Button onClick={handleStartRecognition}>开始识别打卡</Button>}
                    </div>
                </div>

                <Modal
                    // status 0是上班打卡，1是下班打卡
                    title={status === 0 ? `上班打卡` : `下班打卡`}
                    open={showSuccessModal}
                    onOk={handleSuccessModalOk}
                >
                    {/* time 0是正常，1是迟到，2是早退 ，正常打卡显示绿色，早退和迟到红色警告*/}
                    <p style={{color:time===0?"green":"red"}}>{`${name} - ${time===0?"正常打卡":time===1?"迟到":"早退"}`}</p>
                </Modal>

                <Modal
                    // 打卡失败红色警告
                    title={`打卡失败`}
                    open={showErrorModal}
                    onOk={handleErrorModalOk}
                >
                    <p style={{color:"red"}}>{`${name} - 打卡失败`}</p>
                </Modal>
            </div>
        </div>
    );
};

export default DetectCom;
