// 学生汇总组件页面
import React, {useContext, useEffect, useState} from 'react';
import {
    PieChartOutlined,
    DiffOutlined,
    UploadOutlined,
    FileTextOutlined,
    TeamOutlined,
    GithubOutlined, CameraOutlined,
} from '@ant-design/icons';
import type { MenuProps } from 'antd';
import {Layout, Menu, message} from 'antd';
import UploadFace from "@/pages/student/components/UploadFace";
import DetectCom from "@/pages/student/components/DetectCom";
import Navi from "@/components/Navi";
import {StudentContext} from "@/global/StudentContext";
import PersonalInfo from "@/pages/student/components/PersonalInfo";

import {history} from "@@/core/history";
import AttendanceSingle from "@/pages/student/components/AttendanceSingle";
import {studentInformation} from "@/services/api";

const {  Content, Footer, Sider } = Layout;

type MenuItem = Required<MenuProps>['items'][number];


function getItem(
    label: React.ReactNode,
    key: React.Key,
    icon?: React.ReactNode,
    children?: MenuItem[],
): MenuItem {
    return {
        key,
        icon,
        children,
        label,
    } as MenuItem;
}


const items: MenuItem[] = [
    getItem('识别打卡', 'detect', <CameraOutlined />),
    getItem('人脸录入', 'upload', <UploadOutlined />),
    getItem('个人信息', 'description', <FileTextOutlined />,[
        getItem('签到记录', 'attendances', <TeamOutlined />),
        getItem('信息修改', 'personalInfo', <PieChartOutlined />),
    ]),
    getItem('其他', 'other', <DiffOutlined />),
];

const Index: React.FC = () => {


    const [collapsed, setCollapsed] = useState(false);
    const [selectedItem, setSelectedItem] = useState(''); // 新增的状态变量
    // @ts-ignore
    const ChangePage = (e: any) => {
        setSelectedItem(e.key); // 更新选中的菜单项
    };

    // 设置全局变量信息
    const {studentData, setStudentData} = useContext(StudentContext);

    // 获取session信息
    useEffect(() => {
        studentInformation().then((res:any) => {
            if (res.data.status === 1006) {
                console.log(res.data);
                setStudentData(res.data.data);
            }
            else {
                //console.log(res.data);
                message.error(res.data.msg);
                history.push('/login')
            }
        });
    }, []);

    return (

        <Layout style={{ minHeight: '100vh' }}>
            <Navi />
            <Layout style={{ minHeight: '100vh' }}>
                <Sider
                    theme={"light"}
                    collapsible
                    collapsed={collapsed}
                    onCollapse={(value) => setCollapsed(value)}
                >
                    <div className="demo-logo-vertical" />
                    <Menu onClick={ChangePage} defaultSelectedKeys={['']} mode="inline" items={items} />
                </Sider>
                    <Layout>
                        {/*<Watermark content="AI人脸识别打卡">*/}
                            <Content style={{ margin: '0 16px' }}>
                                {/*介绍学生界面*/}
                                {selectedItem === '' &&
                                <div>
                                    <h1>欢迎使用AI人脸识别打卡系统</h1>
                                    <p>
                                        本系统基于人脸识别技术，实现了人脸识别打卡功能，同时提供了人脸录入、个人信息修改、签到记录等功能。
                                    </p>
                                </div>
                                }

                                {selectedItem === 'detect' && <DetectCom />}
                                {selectedItem === 'upload' && <UploadFace />}
                                {selectedItem === 'attendances' && <AttendanceSingle />}
                                {selectedItem === 'personalInfo' && <PersonalInfo />}
                                {selectedItem === 'other' && <div>该功能还在施工中...</div>}
                            </Content>
                        {/*</Watermark>*/}
                        <Footer style={{textAlign: 'center', position: 'fixed', bottom: 0, width: '100%'}}>
                            <a  href={"https://github.com/Mercurius14"} target={"_blank"} >
                                <GithubOutlined />
                                My GitHub | ©2023 YujianHuang
                            </a>
                        </Footer>
                    </Layout>
            </Layout>
        </Layout>
    );
};

export default Index;
