// 学生出勤信息组件
import React, {useContext, useState} from "react";
import {StudentContext} from "@/global/StudentContext";
import {Radio, RadioChangeEvent, Timeline} from "antd";

const AttendanceSingle: React.FC  = () => {
    // 设置全局变量信息
    const {studentData, setStudentData} = useContext(StudentContext);

    // 提取学生考勤信息
    const attendances = studentData?.attendances;


    const [mode, setMode] = useState<'left' | 'alternate' | 'right'>('left');

    const onChange = (e: RadioChangeEvent) => {
        setMode(e.target.value);
    };


    return (
        <>
            <Radio.Group
                onChange={onChange}
                value={mode}
                style={{
                    marginBottom: 20,
                }}
            >
                <Radio value="left">Left</Radio>
                <Radio value="right">Right</Radio>
                <Radio value="alternate">Alternate</Radio>
            </Radio.Group>
            <Timeline
                mode={mode}
                items={attendances.map((item:any) => {
                    const attendanceTime = new Date(item.attendanceTime);
                    // 减去8个时区
                    attendanceTime.setHours(attendanceTime.getHours() - 8);
                    return {
                        color: item.attendanceStatus === 0 ? 'green' : 'red',
                        // 转化为中国本地时间
                        label: attendanceTime.toLocaleString(),
                        title: item.attendanceType === 0 ? '上班打卡' : '下班打卡',
                        description: item.attendanceStatus === 0 ? '正常' : item.attendanceStatus === 1 ? '迟到' : '早退',
                        children:(
                            <>
                                {/*上班打卡还是下班打卡。早退迟到还是正常*/}
                                <p>{item.attendanceType === 0 ? '上班打卡' : '下班打卡'}：{item.attendanceStatus === 0 ? '正常' : item.attendanceStatus === 1 ? '迟到' : '早退'}</p>
                            </>
                        )
                    }
                })
            }
            />
        </>
    );
}
export default AttendanceSingle;