// 今日考勤记录
import React, {useContext} from "react";
import {Table, TableProps, Tag} from "antd";
import {ColumnsType} from "antd/es/table";
import {StudentsAttendancesDataType} from "../../../../typings";
import {StudentContext} from "@/global/StudentContext";
import ExportAttendance from "@/pages/admin/components/ExportAttendance";




const onChange: TableProps<StudentsAttendancesDataType>['onChange'] = (pagination, filters, sorter, extra) => {
    console.log('params', pagination, filters, sorter, extra);
};
const TodaysPage: React.FC = () => {
    // 设置全局变量信息
    const {studentData, setStudentData} = useContext(StudentContext);
    // 如果studentData为空，说明没有登录，跳转到登录界面
    if (studentData === null) {
        return <></>;
    }
    // 取出所有学生的姓名，去过重的，用于过滤器
    // @ts-ignore
    const stuNames: string[] = [...new Set(studentData?.attendances.map((item: any) => item.stuName))];
    // @ts-ignore
    const stuIds: string[] = [...new Set(studentData?.attendances.map((item: any) => item.stuId))];

    const columns: ColumnsType<StudentsAttendancesDataType> = [
        {
            title: '学号',
            dataIndex: 'stuId',
            filters: stuIds.map((item: string, index) => {
                return {
                    text: item,
                    value: item,
                };
            }),
            onFilter: (value: any, record: any) => record.stuId === value,
        },
        {
            title: '姓名',
            dataIndex: 'stuName',
            filters: stuNames.map((item: string, index) => {
                return {
                    text: item,
                    value: item,
                };
            }),
            onFilter: (value: any, record: any) => record.stuName === value,
        },
        {
            title: '打卡时间',
            dataIndex: 'attendanceType',
            // 0是上班打卡，1是下班打卡
            render: (text: number) => {
                return text === 0 ? '上班打卡' : '下班打卡';
            },
            filters: [
                {
                    text: '上班打卡',
                    value: 0,
                },
                {
                    text: '下班打卡',
                    value: 1,
                },
            ],
            // 过滤器
            onFilter: (value: any, record: any) => record.attendanceType === value,
        },
        {
            title: '打卡情况',
            dataIndex: 'attendanceStatus',
            // 0是正常，1是迟到，2是早退， 正常显示绿色，迟到显示黄色，早退显示红色
            render: (text: number) => {
                // 用Tag组件
                if (text === 0) {
                    return <Tag color="green">正常</Tag>;
                }
                if (text === 1) {
                    return <Tag color="yellow">迟到</Tag>;
                }
                if (text === 2) {
                    return <Tag color="red">早退</Tag>;
                }
            },
            filters: [
                {
                    text: '正常',
                    value: 0,
                },
                {
                    text: '迟到',
                    value: 1,
                },
                {
                    text: '早退',
                    value: 2,
                },
            ],
            // 过滤器
            onFilter: (value: any, record: any) => record.attendanceStatus === value,
        },
        {
            title: '考勤时间',
            dataIndex: 'attendanceTime',
            // 时间排序
            sorter: (a: any, b: any) => {
                return new Date(a.attendanceTime).getTime() - new Date(b.attendanceTime).getTime();
            }
        },

    ];

    // @ts-ignore
    // 过滤出今天的考勤记录
    const data = studentData.attendances.map((item: StudentsAttendancesDataType, index: number) => {
        const today = new Date();
        const attendanceTime = new Date(item.attendanceTime);
        const adjustedTime = new Date(attendanceTime);
        adjustedTime.setHours(adjustedTime.getHours() - 8); // 减去8个时区的偏移量

        // 把满足的日期的考勤日期改成格式化后的字符串
        const time  = `${adjustedTime.getFullYear()}/${adjustedTime.getMonth() + 1}/${adjustedTime.getDate()} ${adjustedTime.getHours()}:${adjustedTime.getMinutes()}:${adjustedTime.getSeconds()}`;

        return {
            key: index,
            stuId: item.stuId,
            stuName: item.stuName,
            attendanceType: item.attendanceType,
            attendanceStatus: item.attendanceStatus,
            attendanceTime: time,
        };
    }).filter((item: StudentsAttendancesDataType) => {
        const attendanceTime = new Date(item.attendanceTime);
        const today = new Date();
        return today.getFullYear() === attendanceTime.getFullYear() &&
            today.getMonth() === attendanceTime.getMonth() &&
            today.getDate() === attendanceTime.getDate();
    });



    return (
        <div>
            <h1>今日考勤记录</h1>
            <Table
                columns={columns}
                dataSource={data}
                onChange={onChange}
            />
            <ExportAttendance values={data}/>
        </div>
    );
}
export default TodaysPage