// 放图表的界面
import PieCharts from "@/pages/admin/components/charts/PieCharts";
import BarCharts from "@/pages/admin/components/charts/BarCharts";
import React from "react";

const VisualCharts: React.FC = () => {

    return (
        <div>
            <PieCharts />
            <BarCharts />
        </div>
    );
};

export default VisualCharts;
