// 导出功能
import React from "react";
import * as XLSX from 'xlsx';
import {Button} from "antd";

type ExportAttendanceProps = {
    values: any;
};
const ExportAttendance: React.FC<ExportAttendanceProps> = (props) => {
    function downloadFile() {
        // data 是studentData.attendances的复制
        const data = JSON.parse(JSON.stringify(props.values));
        // 调整一下导出的数据格式
        data.forEach((item: any) => {
            item.stuId = item.stuId.toString();
            item.stuName = item.stuName.toString();
            item.attendanceType = item.attendanceType === 0 ? '上班打卡' : '下班打卡';
            // 0是正常，1是迟到，2是早退
            item.attendanceStatus = item.attendanceStatus === 0 ? '正常' : item.attendanceStatus === 1 ? '迟到' : '早退';
            item.attendanceTime = new Date(item.attendanceTime).toLocaleString();
        });
        // 修改键名
        const keyMap = {
            stuId: '学号',
            stuName: '姓名',
            attendanceType: '打卡类型',
            attendanceStatus: '打卡状态',
            attendanceTime: '打卡时间',
            id:"id"

        };
        // 将data的每一项的键名改为对应的中文
        data.forEach((item: any) => {
            const keys = Object.keys(item);
            keys.forEach((key: any) => {
                // @ts-ignore
                item[keyMap[key]] = item[key];
                delete item[key];
            });
        });

        // 创建一个工作簿对象
        const workbook = XLSX.utils.book_new();

        // 创建一个工作表对象
        const worksheet = XLSX.utils.json_to_sheet(data);

        // 将工作表添加到工作簿中
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

        // 将工作簿转换为二进制数据流
        const excelData = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });

        // 创建一个 Blob 对象
        const blob = new Blob([excelData], { type: 'application/octet-stream' });

        // 创建一个临时 URL
        const url = URL.createObjectURL(blob);

        // 创建一个链接元素并设置相关属性
        const link = document.createElement('a');
        link.href = url;
        link.download = 'attendances.xlsx';

        // 将链接元素添加到文档中
        document.body.appendChild(link);

        // 模拟点击链接进行下载
        link.click();

        // 清理临时 URL
        URL.revokeObjectURL(url);
    }

    return (
        <div>
            <Button onClick={downloadFile} type="primary">导出</Button>
        </div>
    );
}
export default ExportAttendance;