import React, { useContext, useEffect, useRef, useState } from 'react';
import type { InputRef } from 'antd';
import { Button, Form, Input, message, Popconfirm, Table, Tag } from 'antd';
import type { FormInstance } from 'antd/es/form';
import { StudentContext } from "@/global/StudentContext";
import { deleteStudent, updateStudent } from "@/services/api";
import { StudentDataType, StudentEditableCellProps, StudentEditableRowProps } from "../../../../typings";
import { SearchOutlined } from "@ant-design/icons";
import UploadXlsx from "@/pages/admin/components/UploadXlsx";
import {DataType} from "csstype";

// 可编辑内容
const EditableContext = React.createContext<FormInstance<any> | null>(null);

// 可编辑行
const EditableRow: React.FC<StudentEditableRowProps> = ({ index, ...props }) => {
    const [form] = Form.useForm();
    return (
        <Form form={form} component={false}>
            <EditableContext.Provider value={form}>
                <tr {...props} />
            </EditableContext.Provider>
        </Form>
    );
};

// 可编辑单元格
const EditableCell: React.FC<StudentEditableCellProps> = ({
                                                              title,
                                                              editable,
                                                              children,
                                                              dataIndex,
                                                              record,
                                                              handleSave,
                                                              ...restProps
                                                          }) => {
    const [editing, setEditing] = useState(false);
    const inputRef = useRef<InputRef>(null);
    const form = useContext(EditableContext)!;

    // 使得编辑状态下自动聚焦
    useEffect(() => {
        if (editing) {
            inputRef.current!.focus();
        }
    }, [editing]);

    // 切换编辑状态
    const toggleEdit = () => {
        setEditing(!editing);
        form.setFieldsValue({ [dataIndex]: record[dataIndex] });
    };

    // 保存修改
    const save = async () => {
        try {
            const values = await form.validateFields();

            toggleEdit();
            handleSave({ ...record, ...values });
        } catch (errInfo) {
            console.log('Save failed:', errInfo);
        }
    };

    // 渲染
    let childNode = children;
    // 可编辑状态
    if (editable) {
        childNode = editing ? (
            <Form.Item
                style={{ margin: 0 }}
                name={dataIndex}
                rules={[
                    {
                        required: true,
                        message: `${title} is required.`,
                    },
                ]}
            >
                <Input ref={inputRef} onPressEnter={save} onBlur={save} />
            </Form.Item>
        ) : (
            <div className="editable-cell-value-wrap" style={{ paddingRight: 1 }} onClick={toggleEdit}>
                {children}
            </div>
        );
    }

    return <td {...restProps}>{childNode}</td>;
};

//  可编辑表格参数
type EditableTableProps = Parameters<typeof Table>[0] & {
    scroll?: {
        x?: number | true | string;
        y?: number | string;
    };
};

type ColumnTypes = Exclude<EditableTableProps['columns'], undefined>;

// ---------------------------主部分---------------------------------
const StudentsPage: React.FC = () => {
    // 搜索框
    const [searchText, setSearchText] = useState('');
    const [filteredData, setFilteredData] = useState<StudentDataType[]>([]);

    // 获取全局学生数据
    const { studentData, setStudentData } = useContext(StudentContext);

    // 初始化表格数据
    const [dataSource, setDataSource] = useState<StudentDataType[]>(
        studentData?.students.map((item: any) => ({
            key: item.id,
            stuId: item.stuId,
            name: item.name,
            stuGroup: item.stuGroup,
            stuState: item.stuState,
            createTime: new Date(item.createTime).toLocaleString(), // 时间格式化
            updateTime: new Date(item.updateTime).toLocaleString(),
        }))
    );
    // 如果全局变量studentData发生变化，更新表格数据
    useEffect(() => {
        // 创建时间和更新时间减去8小时

        setDataSource(
            studentData?.students.map((item: any) => ({
                key: item.id,
                stuId: item.stuId,
                name: item.name,
                stuGroup: item.stuGroup,
                stuState: item.stuState,
                createTime: new Date(item.createTime).toLocaleString(),
                updateTime: new Date(item.updateTime).toLocaleString(),
            }))
        );
    }, [studentData]);

    // 得到所有group
    const group = studentData?.groups.map((item: any) => item.groupName);

    const [count, setCount] = useState(
        // stuId（是str类型）值最大的一个+1
        Math.max.apply(
            null,
            studentData?.students.map((item: any) => parseInt(item.stuId))
        ) + 1
    );

    // 处理删除
    const handleDelete = async (key: React.Key) => {
        const newData = dataSource.filter((item) => item.key !== key);
        // 删除后更新数据，获得删除的学生
        const deleteStu = dataSource.filter((item: any) => item.key === key);
        console.log("删除的学生", deleteStu);
        const result = await deleteStudent(deleteStu);
        if (result.status === 1008) {
            message.success(result.msg);
            setDataSource(newData);
            // 更新全局变量
            setStudentData({
                num: studentData?.num - 1,
                attendances: studentData?.attendances,
                students: studentData?.students.filter((item: any) => item.id !== deleteStu[0].key),
                // 对应组别的学生数减一
                groups: studentData?.groups.map((item: any) => {
                    if (item.groupName === deleteStu[0].stuGroup) {
                        return {
                            ...item,
                            groupNum: item.groupNum - 1,
                        };
                    } else {
                        return item;
                    }
                }),
            });
        } else {
            message.error(result.msg);
        }
    };

    // 添加一行
    const handleAdd = async () => {
        const newData: StudentDataType = {
            key: count,
            stuId: (20210000 + count + 1).toString(),
            name: `学生${count}`,
            stuGroup: group[0],
            stuState: 0,
            createTime: new Date().toLocaleString(),
            updateTime: new Date().toLocaleString(),
        };

        const result = await updateStudent(newData);
        if (result?.status === 1007) {
            setDataSource([...dataSource, newData]);
            setCount(count + 1);
            // 更新全局变量
            setStudentData({
                num: studentData?.num + 1,
                attendances: studentData?.attendances,
                students: [...studentData?.students, {
                    id: newData.key,
                    stuId: newData.stuId,
                    name: newData.name,
                    stuGroup: newData.stuGroup,
                    stuState: newData.stuState,
                    createTime: newData.createTime,
                    updateTime: newData.updateTime,
                }],
                groups: studentData?.groups.map((item: any) => {
                    if (item.groupName === newData.stuGroup) {
                        return {
                            ...item,
                            createTime: new Date(item.createTime).toLocaleString(),
                            updateTime: new Date().toLocaleString(),
                            groupNum: item.groupNum + 1,
                        }
                    } else {
                        return item;
                    }
                }),
            });
        } else {
            message.error(result.msg);
        }
    };

    // 搜索框处理逻辑
    const handleSearch = (selectedKeys: string[]) => {
        const filtered = dataSource.filter((item) =>
            item.stuId.toLowerCase().includes(selectedKeys[0].toLowerCase())
        );
        setFilteredData(filtered);
    };

    const handleReset = () => {
        setFilteredData([]);
        setSearchText('');
    };

    // 保存修改
    const handleSave = async (row: StudentDataType) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];
        newData.splice(index, 1, {
            ...item,
            ...row,
        });

        const result = await updateStudent(newData[index]);
        if (result?.status === 1007) {
            setDataSource(newData);
            setStudentData({
                num: studentData?.num,
                attendances: studentData?.attendances,
                students: studentData?.students.map((item: any) => {
                    if (item.id === newData[index].key) {
                        return { ...newData[index], id: newData[index].key, key: undefined, updateTime: new Date().toLocaleString() }
                    } else {
                        return item;
                    }
                }),
                groups: studentData?.groups.map((data: any) => {
                    if (item.stuGroup === newData[index].stuGroup) {
                        return data;
                    } else {
                        if (data.groupName === newData[index].stuGroup) {
                            return {
                                ...data,
                                groupNum: data.groupNum + 1,
                                createTime: new Date(data.createTime).toLocaleString(),
                                updateTime: new Date().toLocaleString(),
                            };
                        } else if (data.groupName === item.stuGroup) {
                            return {
                                ...data,
                                groupNum: data.groupNum - 1,
                                createTime: new Date(data.createTime).toLocaleString(),
                                updateTime: new Date().toLocaleString(),
                            };
                        } else {
                            return data;
                        }
                    }
                }),
            });
            message.success(result.msg);
        } else {
            message.error(result.msg);
        }
    };

    // 定义每行数据类型
    const defaultColumns: (ColumnTypes[number] & { editable?: boolean; dataIndex: string })[] = [
        {
            title: '学号',
            dataIndex: 'stuId',
            editable: true,
        },
        {
            title: '姓名',
            dataIndex: 'name',
            editable: true,
        },
        {
            title: '组别',
            dataIndex: 'stuGroup',
            editable: true,
            filters: group.map((item: any) => ({ text: item, value: item })),
            // @ts-ignore
            onFilter: (value: any, record: DataType) => record.stuGroup === value,
        },
        {
            title: '状态',
            dataIndex: 'stuState',
            editable: true,
            render: (text, record) => {
                // @ts-ignore
                const state = record.stuState;
                return (
                    <Tag color={state === 0 ? 'green' : 'red'} key={state}>
                        {state === 0 ? '正常' : '异常'}
                    </Tag>
                );
            },
            filters: [
                {
                    text: '正常',
                    value: 0,
                },
                {
                    text: '异常',
                    value: 1,
                },
            ],
            // @ts-ignore
            onFilter: (value: any, record: DataType) => record.stuState === value,
        },
        {
            title: '创建时间',
            dataIndex: 'createTime',
            sorter: (a: any, b: any) => {
                return new Date(a.createTime).getTime() - new Date(b.createTime).getTime();
            },
        },
        {
            title: '更新时间',
            dataIndex: 'updateTime',
            sorter: (a: any, b: any) => {
                return new Date(a.updateTime).getTime() - new Date(b.updateTime).getTime();
            },
        },
        {
            title: '操作',
            dataIndex: 'operation',
            // @ts-ignore
            render: (_, record: { key: React.Key }) =>
                dataSource.length >= 1 ? (
                    <Popconfirm title="确定删除？" onConfirm={() => handleDelete(record.key)}>
                        <a>删除</a>
                    </Popconfirm>
                ) : null,
        },
    ];

    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };

    const columns = defaultColumns.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record: StudentDataType) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                handleSave,
            }),
        };
    });

    const tableScroll = { x: 800, y: 300 };

    const handleSearchTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchText(e.target.value);
    };

    const handleSearchSubmit = () => {
        handleSearch([searchText]);
    };

    return (
        <>
            <div>
                <Button onClick={handleAdd} type="primary" style={{ marginBottom: 8, marginRight: '8px' }}>
                    添加学生
                </Button>
                <UploadXlsx />
                <Input
                    placeholder="请输入要搜索的学号"
                    value={searchText}
                    onChange={handleSearchTextChange}
                    style={{ width: '200px', marginRight: '16px' }}
                />
                <Button type="primary" icon={<SearchOutlined />} onClick={handleSearchSubmit}>
                    搜索
                </Button>
                <Button onClick={handleReset} style={{ marginLeft: '8px' }}>
                    重置
                </Button>
            </div>
            <Table
                components={components}
                rowClassName={() => 'editable-row'}
                bordered
                dataSource={filteredData.length > 0 ? filteredData : dataSource}
                rowKey="key"
                columns={columns as ColumnTypes}
                scroll={tableScroll}
            />
        </>
    );
};

export default StudentsPage;
