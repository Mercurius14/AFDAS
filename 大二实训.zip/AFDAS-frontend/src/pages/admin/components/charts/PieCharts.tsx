// 饼状图
import React, { useContext, useEffect, useRef } from "react";
import { StudentContext } from "@/global/StudentContext";
import * as echarts from "echarts";

const PieCharts: React.FC = () => {
    const { studentData } = useContext(StudentContext);
    const studentsNum = studentData?.students.length;
    const morningChartRef = useRef<HTMLDivElement | null>(null);
    const afternoonChartRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        if (morningChartRef.current && afternoonChartRef.current && studentData) {
            const morningChart = echarts.init(morningChartRef.current);
            const afternoonChart = echarts.init(afternoonChartRef.current);

            const morningStatusCounts = {
                normal: 0,
                late: 0,
                earlyLeave: 0,
                absent: 0,
            };

            const afternoonStatusCounts = {
                normal: 0,
                late: 0,
                earlyLeave: 0,
                absent: 0,
            };

            studentData.attendances.forEach((item: any) => {
                const attendanceTime = new Date(item.attendanceTime);
                // 判断是否是今天， 0是正常、1是迟到、2是早退
                if (attendanceTime.toDateString() === new Date().toDateString()) {
                    if (item.attendanceType === 0) {
                        if (item.attendanceStatus === 0) {
                            morningStatusCounts.normal++;
                        } else if (item.attendanceStatus === 1) {
                            morningStatusCounts.late++;
                        } else if (item.attendanceStatus === 2) {
                            morningStatusCounts.earlyLeave++;
                        }
                    } else if (item.attendanceType === 1) {
                        if (item.attendanceStatus === 0) {
                            afternoonStatusCounts.normal++;
                        } else if (item.attendanceStatus === 1) {
                            afternoonStatusCounts.late++;
                        } else if (item.attendanceStatus === 2) {
                            afternoonStatusCounts.earlyLeave++;
                        }
                    }
                }
            });

            morningStatusCounts.absent =
                studentsNum -
                morningStatusCounts.normal -
                morningStatusCounts.late -
                morningStatusCounts.earlyLeave;
            afternoonStatusCounts.absent =
                studentsNum -
                afternoonStatusCounts.normal -
                afternoonStatusCounts.late -
                afternoonStatusCounts.earlyLeave;

            const morningOption = {
                title: {
                    text: "今日上午出勤状态",
                    left: "center",
                },
                series: [
                    {
                        name: "今日上午出勤状态",
                        type: "pie",
                        radius: "55%",
                        center: ["50%", "60%"],
                        data: [
                            { value: morningStatusCounts.normal, name: "正常" },
                            { value: morningStatusCounts.late, name: "迟到" },
                            { value: morningStatusCounts.earlyLeave, name: "早退" },
                            { value: morningStatusCounts.absent, name: "未考勤", itemStyle: { color: "#808080" } },
                        ],
                    },
                ],
                // 显示数目
                label: {
                    formatter: "{b}: {c}",
                },
            };

            const afternoonOption = {
                title: {
                    text: "今日下午出勤状态",
                    left: "center",
                },
                series: [
                    {
                        name: "今日下午出勤状态",
                        type: "pie",
                        radius: "55%",
                        center: ["50%", "60%"],
                        data: [
                            { value: afternoonStatusCounts.normal, name: "正常" },
                            { value: afternoonStatusCounts.late, name: "迟到" },
                            { value: afternoonStatusCounts.earlyLeave, name: "早退" },
                            { value: afternoonStatusCounts.absent, name: "未考勤", itemStyle: { color: "#808080" } },
                        ],
                    },
                ],
                // 显示数目
                label: {
                    formatter: "{b}: {c}",
                },
            };

            morningChart.setOption(morningOption);
            afternoonChart.setOption(afternoonOption);
        }
    }, [studentData]);

    return (
        <div style={{ display:"flex" }}>
            <div style={{ width: "400px", height: "400px" }} ref={morningChartRef}></div>
            <div style={{ width: "400px", height: "400px" }} ref={afternoonChartRef}></div>
        </div>
    );
};

export default PieCharts;
