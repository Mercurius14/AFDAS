// 柱状图
import React, { useContext, useEffect, useRef, useState } from "react";
import { StudentContext } from "@/global/StudentContext";
import * as echarts from "echarts";
import { Button } from "antd";
import moment from "moment";

const BarCharts: React.FC = () => {
    const { studentData } = useContext(StudentContext);
    const studentsNum = studentData?.students.length;
    const chartRef = useRef<HTMLDivElement | null>(null);
    const [isMorning, setIsMorning] = useState(true);

    useEffect(() => {
        if (chartRef.current && studentData) {
            const chart = echarts.init(chartRef.current);

            const startOfWeek = moment().startOf("week").add(1, "day");
            const xAxisData = ["周一", "周二", "周三", "周四", "周五"];
            const seriesData = [];

            for (let i = 0; i < 5; i++) {
                const morningStatusCounts = {
                    normal: 0,
                    late: 0,
                    earlyLeave: 0,
                    absent: 0,
                };

                const afternoonStatusCounts = {
                    normal: 0,
                    late: 0,
                    earlyLeave: 0,
                    absent: 0,
                };

                const adjustedStudentData = JSON.parse(
                    JSON.stringify(studentData.attendances)
                ); // 创建studentData的副本

                // 调整时区为北京时间
                adjustedStudentData.forEach((item: any) => {
                    const adjustedTime = moment(item.attendanceTime).subtract(8, 'hours');
                    // console.log(adjustedTime.format("YYYY-MM-DD HH:mm:ss"));
                });

                adjustedStudentData.forEach((item: any) => {
                    const attendanceTime = moment(item.attendanceTime).subtract(8, 'hours');
                    if (attendanceTime.day() === i + 1) {
                        if (attendanceTime.hour() < 12) {
                            if (item.attendanceStatus === 0) {
                                morningStatusCounts.normal++;
                            } else if (item.attendanceStatus === 1) {
                                morningStatusCounts.late++;
                            } else if (item.attendanceStatus === 2) {
                                morningStatusCounts.earlyLeave++;
                            }
                        } else {
                            if (item.attendanceStatus === 0) {
                                afternoonStatusCounts.normal++;
                            } else if (item.attendanceStatus === 1) {
                                afternoonStatusCounts.late++;
                            } else if (item.attendanceStatus === 2) {
                                afternoonStatusCounts.earlyLeave++;
                            }
                        }
                    }
                });


                morningStatusCounts.absent =
                    studentsNum! -
                    morningStatusCounts.normal -
                    morningStatusCounts.late -
                    morningStatusCounts.earlyLeave;
                afternoonStatusCounts.absent =
                    studentsNum! -
                    afternoonStatusCounts.normal -
                    afternoonStatusCounts.late -
                    afternoonStatusCounts.earlyLeave;

                // Add data to seriesData
                if (isMorning) {
                    seriesData.push([
                        morningStatusCounts.normal,
                        morningStatusCounts.late,
                        morningStatusCounts.earlyLeave,
                        morningStatusCounts.absent,
                    ]);
                } else {
                    seriesData.push([
                        afternoonStatusCounts.normal,
                        afternoonStatusCounts.late,
                        afternoonStatusCounts.earlyLeave,
                        afternoonStatusCounts.absent,
                    ]);
                }
            }

            const option = {
                title: {
                    text: isMorning ? "上午考勤统计" : "下午考勤统计",
                },
                legend: {
                    data: ["正常", "迟到", "早退", "未考勤"],
                },
                tooltip: {
                    trigger: "axis",
                    axisPointer: {
                        type: "shadow",
                    },
                },
                xAxis: {
                    type: "category",
                    data: xAxisData,
                },
                yAxis: {
                    type: "value",
                },
                series: [
                    {
                        name: "正常",
                        type: "bar",
                        stack: "总量",
                        data: seriesData.map((data) => data[0]),
                    },
                    {
                        name: "迟到",
                        type: "bar",
                        stack: "总量",
                        data: seriesData.map((data) => data[1]),
                    },
                    {
                        name: "早退",
                        type: "bar",
                        stack: "总量",
                        data: seriesData.map((data) => data[2]),
                    },
                    {
                        name: "未考勤",
                        type: "bar",
                        stack: "总量",
                        data: seriesData.map((data) => data[3]),
                        // 颜色
                        itemStyle: {
                            color: "#808080"
                        }
                    },
                ],
            };

            chart.setOption(option);
        }
    }, [studentData, studentsNum, isMorning]);

    return (
        <div>
            <div style={{ width: "100%", height: "400px" }} ref={chartRef}></div>
            <Button type="primary" onClick={() => setIsMorning(!isMorning)}>
                {isMorning ? "查看下午考勤" : "查看上午考勤"}
            </Button>
        </div>
    );
};

export default BarCharts;