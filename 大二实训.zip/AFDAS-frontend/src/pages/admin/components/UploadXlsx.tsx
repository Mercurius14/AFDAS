import { Upload, message, Button } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import { UploadChangeParam } from 'antd/es/upload';
import { getStudents } from '@/services/api';
import {useContext} from "react";
import {StudentContext} from "@/global/StudentContext";

const UploadXlsx = () => {
    const { setStudentData } = useContext(StudentContext);

    const props = {
        name: 'file',
        action: 'http://localhost:8098/uploadStudent',
        onChange(info: UploadChangeParam) {
            const { status } = info.file;
            if (status !== 'uploading') {
                console.log(info.file, info.fileList);
            }
            if (status === 'done') {
                const { data, status,msg } = info.file.response;
                // console.log("上传之后的response",info.file.response);
                if (data && status === 1007) {
                    // 在上传完成后调用getStudents()获取最新的学生数据并更新全局变量
                    message.success(msg);
                    getStudents()
                        .then(response => {
                            //console.log("更新数据response",response);
                            if (response.status === 1006) {
                                setStudentData(response.data);
                            } else {
                                message.error(response.msg);
                            }
                        })
                        .catch(error => {
                            console.error(error);
                        });
                } else {
                    message.error(msg);
                }
            } else if (status === 'error') {
                message.error(`${info.file.name} file upload failed.`);
            }
        },
    };

    return (
        <Upload {...props}>
            <Button icon={<UploadOutlined />}>上传学生文件</Button>
        </Upload>
    );
};

export default UploadXlsx;
