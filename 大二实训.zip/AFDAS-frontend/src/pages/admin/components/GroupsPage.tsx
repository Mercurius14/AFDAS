// 组别管理页面

import React, { useContext, useEffect, useRef, useState } from 'react';
import type { InputRef } from 'antd';
import {Button, Form, Input, message, Popconfirm, Table} from 'antd';
import type { FormInstance } from 'antd/es/form';
import {StudentContext} from "@/global/StudentContext";
import {deleteGroup, updateGroup} from "@/services/api";
import {GroupEditableRowProps, GroupEditableCellProps, GroupDataType} from "../../../../typings";
import {SearchOutlined} from "@ant-design/icons";


// 可编辑内容
const EditableContext = React.createContext<FormInstance<any> | null>(null);

// 可编辑行
const EditableRow: React.FC<GroupEditableRowProps> = ({ index, ...props }) => {
    const [form] = Form.useForm();
    return (
        <Form form={form} component={false}>
            <EditableContext.Provider value={form}>
                <tr {...props} />
            </EditableContext.Provider>
        </Form>
    );
};

// 可编辑单元格
const EditableCell: React.FC<GroupEditableCellProps> = ({
                                                              title,
                                                              editable,
                                                              children,
                                                              dataIndex,
                                                              record,
                                                              handleSave,
                                                              ...restProps
                                                          }) => {
    const [editing, setEditing] = useState(false);
    const inputRef = useRef<InputRef>(null);
    const form = useContext(EditableContext)!;

    // 使得编辑状态下自动聚焦
    useEffect(() => {
        if (editing) {
            inputRef.current!.focus();
        }
    }, [editing]);

    // 切换编辑状态
    const toggleEdit = () => {
        setEditing(!editing);
        form.setFieldsValue({ [dataIndex]: record[dataIndex] });
    };

    // 保存修改
    const save = async () => {
        try {
            const values = await form.validateFields();

            toggleEdit();
            handleSave({ ...record, ...values });
        } catch (errInfo) {
            console.log('Save failed:', errInfo);
        }
    };

    // 渲染
    let childNode = children;
    // 可编辑状态
    if (editable) {
        childNode = editing ? (
            <Form.Item
                style={{ margin: 0 }}
                name={dataIndex}
                rules={[
                    {
                        required: true,
                        message: `${title} is required.`,
                    },
                ]}
            >
                <Input ref={inputRef} onPressEnter={save} onBlur={save} />
            </Form.Item>
        ) : (
            <div className="editable-cell-value-wrap" style={{ paddingRight: 1 }} onClick={toggleEdit}>
                {children}
            </div>
        );
    }

    return <td {...restProps}>{childNode}</td>;
};

//  可编辑表格参数
type EditableTableProps = Parameters<typeof Table>[0] & {
    scroll?: {
        x?: number | true | string;
        y?: number | string;
    };
};

type ColumnTypes = Exclude<EditableTableProps['columns'], undefined>;


// ---------------------------主部分---------------------------------
const GroupsPage: React.FC = () => {
    // 获取全局组别数据
    const { studentData, setStudentData } = useContext(StudentContext);
    // console.log("表格数据", studentData);
    // 初始化表格数据
    const [dataSource, setDataSource] = useState<GroupDataType[]>(
        studentData?.groups.map((item: any) => ({
            key: item.id,
            groupName: item.groupName,
            groupNum: item.groupNum,
            createTime: new Date(item.createTime).toLocaleString(), // 时间格式化
        }))
    );
    // 得到所有group
    // const group = studentData?.groups.map((item: any) => item.groupName);

    const [count, setCount] = useState(
        // 组别长度+1
        studentData?.groups.length + 1
    );
    // 处理删除
    const handleDelete = async (key: React.Key) => {
        const newData = dataSource.filter((item) => item.key !== key);
        // 删除后更新数据，获得删除的组别
        const deleteStu = dataSource.filter((item: any) => item.key === key);
        console.log("删除的组别", deleteStu);
        const result = await deleteGroup(deleteStu);
        if (result.status === 1010) {
            message.success(result.msg);
            setDataSource(newData);
            // 更新全局变量，注意把key转换为id
            setStudentData({
                num: studentData?.num,
                attendances: studentData?.attendances,
                groups: studentData?.groups.filter((item: any) => item.id !== key),
                students: studentData?.students,
            });
        }
        else{
            message.error(result.msg);
        }
    };

    // 添加一行
    const handleAdd = async () => {
        const newData: GroupDataType = {
            key: count,
            groupName: `Group ${count}`,
            groupNum: 0,
            // 获得当前时间
            createTime: new Date().toLocaleString(),
        };
        console.log(newData);
        const result = await updateGroup(newData);
        if (result?.status === 1009) {
            console.log("新增后的数据", result)
            setDataSource([...dataSource, newData]);
            setCount(count + 1);
            // 更新全局变量
            setStudentData({
                num: studentData?.num,
                attendances: studentData?.attendances,
                // 转换的时候把newData里面的key转换为id，并且去掉key，因为后端没有key
                groups: [...studentData?.groups, { ...newData, id: newData.key, key: undefined }],
                students: studentData?.students,
            });
        } else {
            message.error(result.msg);
        }

    };

    // 保存修改
    const handleSave = async (row: GroupDataType) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];
        newData.splice(index, 1, {
            ...item,
            ...row,
        });
        // console.log("修改后的数据", newData[index])
        const result = await updateGroup(newData[index]);
        if (result?.status === 1009) {
            console.log("修改后的数据", result)
            // setGroupData(result);
            setDataSource(newData);
            // 更新全局变量
            setStudentData({
                num: studentData?.num,
                attendances: studentData?.attendances,
                groups: studentData?.groups.map((item: any) => {
                    if (item.id === row.key) {
                        return { ...newData[index], id: newData[index].key, key: undefined };
                    }
                    else {
                        return item;
                    }
                }),
                students: studentData?.students,
            });
            message.success(result.msg);
        }
        else {
            message.error(result.msg);
        }

    };

    //studentData变化之后打印控制台打印
    // useEffect(() => {
    //     console.log("studentData变化", studentData);
    // }, [studentData]);



    // 定义每行数据类型
    const defaultColumns: (ColumnTypes[number] & { editable?: boolean; dataIndex: string })[] = [
        {
            title: '组名',
            dataIndex: 'groupName',
            editable: true,
        },
        {
            title: '学生数量',
            dataIndex: 'groupNum',
            editable: false,
            // 排序
            sorter: (a: any, b: any) => a.groupNum - b.groupNum,
        },
        {
            title: '创建时间',
            dataIndex: 'createTime',
            // 时间排序
            sorter: (a: any, b: any) => {
                return new Date(a.createTime).getTime() - new Date(b.createTime).getTime();
            }
        },

        {
            title: '操作',
            dataIndex: 'operation',
            // @ts-ignore
            // 如果groupNum不为0，不显示删除按钮
            render: (_, record: GroupDataType) => {
                return dataSource.length >= 1 ? (
                    <Popconfirm title="确定要删除？" onConfirm={() => handleDelete(record.key)}>
                        <a>删除</a>
                    </Popconfirm>
                ) : null;
            }
        },
    ];


    // 搜索框
    const [searchText, setSearchText] = useState('');
    const [filteredData, setFilteredData] = useState<GroupDataType[]>([]);

    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };

    // 搜索框处理逻辑
    const handleSearch = (selectedKeys: string[]) => {
        const filtered = dataSource.filter((item) =>
            item.groupName.toLowerCase().includes(selectedKeys[0].toLowerCase())
        );
        setFilteredData(filtered);
    };

    const handleReset = () => {
        setFilteredData([]);
        setSearchText('');
    };
    const handleSearchTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchText(e.target.value);
    };

    const handleSearchSubmit = () => {
        handleSearch([searchText]);
    };
    const columns = defaultColumns.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record: GroupDataType) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                handleSave,
            }),
        };
    });

    const tableScroll = { x: 800, y: 300 }; // 设置适当的宽度和高度

    return (
        <>
            <div>
                <Button onClick={handleAdd} type="primary" style={{ marginBottom: 16, marginRight: '16px'}}>
                    添加组别
                </Button>
                <Input
                    placeholder="请输入要搜索的组别"
                    value={searchText}
                    onChange={handleSearchTextChange}
                    style={{ width: '200px', marginRight: '16px' }}
                />
                <Button type="primary" icon={<SearchOutlined />}  onClick={handleSearchSubmit}>
                    搜索
                </Button>
                <Button onClick={handleReset} style={{ marginLeft: '8px' }}>
                    重置
                </Button>

            </div>
            <Table
                components={components}
                rowClassName={() => 'editable-row'}
                bordered
                dataSource={filteredData.length > 0 ? filteredData : dataSource}
                rowKey="key"
                columns={columns as ColumnTypes}
                scroll={tableScroll}
            />
        </>
    );
};

export default GroupsPage;
