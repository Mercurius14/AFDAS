// 用途：管理员界面


import React, { useContext, useState, useEffect } from 'react';
import {
    FileTextOutlined,
    TeamOutlined,
    UserOutlined,
    GithubOutlined, TagsOutlined, TabletOutlined, CarryOutOutlined, AreaChartOutlined,
} from '@ant-design/icons';
import type { MenuProps } from 'antd';
import {Layout, Menu, message, theme} from 'antd';
import Navi from "@/components/Navi";
import StudentsPage from "@/pages/admin/components/StudentsPage";
import AttendancesPage from "@/pages/admin/components/AttendancesPage";
import {StudentContext} from "@/global/StudentContext";
import {getStudents} from "@/services/api";
import GroupsPage from "@/pages/admin/components/GroupsPage";
import TodaysPage from "@/pages/admin/components/TodaysPage";
import VisualCharts from "@/pages/admin/components/VisualCharts";
import {history} from "@@/core/history";


const { Content, Footer, Sider } = Layout;

type MenuItem = Required<MenuProps>['items'][number];


function getItem(
    label: React.ReactNode,
    key: React.Key,
    icon?: React.ReactNode,
    children?: MenuItem[],
): MenuItem {
    return {
        key,
        icon,
        children,
        label,
    } as MenuItem;
}


const items: MenuItem[] = [
    getItem('签到信息', 'attendances', <TagsOutlined />, [
        getItem('签到情况', 'attSuitation',<TabletOutlined />),
        getItem('今日签到', 'todayAtten', <CarryOutOutlined />),
    ]),
    getItem('信息可视化', 'visual', <AreaChartOutlined />),
    getItem('信息管理', 'informations', <FileTextOutlined />, [
        getItem('学生管理', 'stuInform', <UserOutlined />),
        getItem('组别信息', 'groupInform', <TeamOutlined />),
    ]),
];

const AdminPage: React.FC = () => {
    const [collapsed, setCollapsed] = useState(false);
    const [selectedItem, setSelectedItem] = useState(''); // 新增的状态变量
    const {setStudentData } = useContext(StudentContext);

    const ChangePage = (e: any) => {
        setSelectedItem(e.key); // 更新选中的菜单项
    };

    useEffect(() => {
        // 在组件渲染之前发送GET请求
        const fetchData = async () => {
            try {
                const response = await getStudents();
                console.log("response", response?.data);
                if (response.status === 1006) {
                    console.log(response.data);
                    setStudentData(response.data);
                }
                else {
                    //console.log(res.data);
                    message.error(response.msg);
                    history.push('/login')
                }
            } catch (error) {
                console.error(error);
            }
        };
        fetchData();

        return () => {
            // 在组件卸载时执行一些清理操作
        };
    }, []);


    return (
        <Layout style={{ minHeight: '100vh' }}>
            <Navi />
            <Layout style={{ minHeight: '100vh' }}>
                <Sider
                    theme={"light"}
                    collapsible
                    collapsed={collapsed}
                    onCollapse={(value) => setCollapsed(value)}
                >
                    <div className="demo-logo-vertical" />
                    <Menu onClick={ChangePage} defaultSelectedKeys={['']} mode="inline" items={items} />
                </Sider>
                <Layout>
                    <Content style={{ margin: '0 16px' }}>
                        {/* 介绍管理员界面可查看的信息 */}
                        {selectedItem === '' &&
                            <div>
                                <h1>管理员界面</h1>
                                <p>这里可以查看学生和组别的信息并进行管理，同时也能查看考勤情况以及今日的考勤情况。我们也提供了可视化的部分来方便管理查看。
                                </p>
                            </div>
                        }
                        {/* 选中学生管理时显示  学生管理 */}
                        {selectedItem === 'stuInform' && <StudentsPage />}
                        {/* 选中组别信息时显示  组别信息 */}
                        {selectedItem === 'groupInform' && <GroupsPage />}
                        {/* 选中签到情况时显示  签到情况 */}
                        {selectedItem === 'attSuitation' && <AttendancesPage />}
                        {/* 选中今日签到时显示  今日签到 */}
                        {selectedItem === 'todayAtten' && <TodaysPage />}
                        {/* 选中信息可视化时显示  信息可视化 */}
                        {selectedItem === 'visual' && <VisualCharts />}

                    </Content>
                    <Footer style={{ textAlign: 'center' }}>
                        <a href={"https://github.com/Mercurius14"} target={"_blank"}>
                            ©2023 YujianHuang | <GithubOutlined />
                            My GitHub
                        </a>
                    </Footer>
                </Layout>
            </Layout>
        </Layout>
    );
};

export default AdminPage;
