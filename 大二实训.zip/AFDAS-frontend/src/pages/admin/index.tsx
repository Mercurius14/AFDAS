// 管理员汇总页面
import React from "react";
import {StudentContextProvider} from "@/global/StudentContext";
import AdminPage from "@/pages/admin/components/AdminPage";
import {getSesstion, Logout} from "@/services/api";
import {message} from "antd";
import {history, useLocation} from "@@/exports";

const Index = () => {
    const location = useLocation();
    const params = new URLSearchParams(location.search);
    const name = params.get('name');
    getSesstion().then((res) => {
        console.log("session保存：",res?.data);
        if (res?.data?.status === 1103 || name != res?.data?.data?.name ){
            // 执行退出登录逻辑
            Logout().then((res) => {
                const informationData = res?.data;
                // console.log(informationData);
                if (informationData?.status === 1011) {
                    history.push("/login");
                }
            })
            // //message.error("登录失败");
            // window.location.href = "/login";    // 重定向到登录页面
        }

    }).catch((err) => {
        console.log("session保存失败：",err);
        message.error("登录失败");
    });

    return (
        <StudentContextProvider>
            <AdminPage />
        </StudentContextProvider>
    );
};

export default Index;
