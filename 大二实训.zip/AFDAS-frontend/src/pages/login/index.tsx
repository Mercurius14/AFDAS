// 登录界面总页面
import LoginPage from "@/pages/login/loginPage";
import {StudentContextProvider} from "@/global/StudentContext";
import {getSesstion} from "@/services/api";
import {message} from "antd";
import {history} from "@@/core/history";

export default () => {
    getSesstion().then((res) => {
        //console.log("session保存：",res?.data);
        const informationData = res?.data;
        if (informationData?.status === 1003){
            // message.success("登录成功");
            if(informationData?.data?.isRole === 0){
                history.push(`/student?name=${informationData?.data?.name}`);
            }
            else{
                history.push(`/admin?name=${informationData?.data?.name}`);
            }
            console.log(informationData?.isRole);
        }


    }).catch((err) => {
        console.log("session保存失败：",err);
        message.error("登录失败");
    });
    return(
        <StudentContextProvider>
            <LoginPage />
        </StudentContextProvider>
    )
};