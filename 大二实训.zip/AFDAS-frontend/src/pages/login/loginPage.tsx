// 登录页面组件
import {
    LockOutlined,
    UserOutlined,
} from '@ant-design/icons';
import {
    LoginForm,
    ProFormText,
} from '@ant-design/pro-components';
import {message, Tabs} from 'antd';
import {useContext, useState} from 'react';
import {handleLoginFormSubmit} from "@/services/api";
import {history} from "@@/core/history";
import { Modal } from 'antd';
import {StudentContext} from "@/global/StudentContext";

type LoginType = 'account';
// 导入图片
import backgroundImage from '@/assets/background.jpg';
import Foot from "@/components/Foot";
const logoImage = require('@/assets/squai.png');

const LoginPage = () => {
    const {setStudentData } = useContext(StudentContext);

    const handleLogin = async (values: any) => {
        try {

            const response = await handleLoginFormSubmit(values);
            if (response) {
                console.log(response.data);
                const role = response.data?.data.isRole;
                const status = response.data?.status;
                // 根据后端返回的信息进行跳转
                if (status === 1001 && role === 0) {
                    // 存储用户信息
                    message.success(`学生 ${response.data?.data.name} 登录成功`)
                    setStudentData(response.data?.data);
                    history.push(`/student?name=${response.data?.data.name}`);
                    // 显示登录成功弹框
                    // Modal.success({
                    //     title: '登录成功',
                    //     content: '欢迎登录！',
                    //     onOk: () => {
                    //         // 跳转到/student
                    //         history.push(`/student?name=${response.data?.data.name}`);
                    //     },
                    // });
                } else if (status === 1001 && role === 1) {
                    message.success(`管理员 ${response.data?.data.name} 登录成功`)
                    // 存储用户信息
                    setStudentData(response.data?.data);
                    history.push(`/admin?name=${response.data?.data.name}`);
                    // 显示登录成功弹框
                    // Modal.success({
                    //     title: '登录成功',
                    //     content: '欢迎登录！',
                    //     onOk: () => {
                    //         // 跳转到/admin
                    //         history.push(`/admin?name=${response.data?.data.name}`);
                    //     },
                    // });
                } else {
                    // 显示登录失败弹框
                    Modal.error({
                        title: '登录失败',
                        content: response.data?.msg,
                    });
                }
            }
        } catch (error) {
            console.error(error);
            // 处理错误情况
            // 示例：message.error('登录失败，请重试！');
        }
    };


    const [loginType, setLoginType] = useState<LoginType>('account');
    return (
        <>
            <div style={{
                backgroundImage: `url(${backgroundImage})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                height: '100vh', // 设置元素高度为100vh，即视口的高度
                backgroundColor: 'white' }}>

                <LoginForm
                    logo={logoImage}
                    title="AI人脸识别打卡系统"
                    subTitle="大二暑期实训"
                    onFinish={handleLogin}
                    // 设置背景
                    // style={{
                    //     backgroundImage: 'url(https://th.bing.com/th/id/OIP.a9w8HIGtum3eR9zfKHRKgAHaEK?w=203&h=114&c=7&r=0&o=5&dpr=1.5&pid=1.7)',
                    //     }}
                >
                    <Tabs
                        centered
                        activeKey={loginType}
                    >
                        <Tabs.TabPane key={'account'} tab={'账号密码登录'} />
                    </Tabs>

                    <ProFormText
                        name="stuId"
                        fieldProps={{
                            size: 'large',
                            prefix: <UserOutlined className={'prefixIcon'} />,
                        }}
                        placeholder={'学号:'}
                        rules={[
                            {
                                required: true,
                                message: '请输入学号!',
                            },
                        ]}
                    />
                    <ProFormText.Password
                        name="password"
                        fieldProps={{
                            size: 'large',
                            prefix: <LockOutlined className={'prefixIcon'} />,
                        }}
                        placeholder={'密码: 不低于5位'}
                        rules={[
                            {
                                required: true,
                                message: '请输入密码！',
                                min: 5,
                            },
                        ]}
                    />

                </LoginForm>
            </div>
            <Foot />
        </>
    );
};

export default LoginPage;