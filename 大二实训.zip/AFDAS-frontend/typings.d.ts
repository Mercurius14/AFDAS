import 'umi/typings';
import React from "react";

// --------------------------组别---------------------------
//  可编辑表格
interface GroupEditableCellProps {
    title: React.ReactNode;
    editable: boolean;
    children: React.ReactNode;
    dataIndex: keyof GroupItem;
    record: GroupItem;
    handleSave: (record: GroupItem) => void;
    filterOption?: any;
}
// 可编辑表格
interface GroupItem {
    key: string;
    groupName: string;
    groupNum: number;
    createTime: string;
    updateTime: string;
}
// 可编辑表格
interface GroupEditableRowProps {
    index: number;
}
// 可编辑表格
interface GroupDataType {
    key: React.Key;
    groupName: string;
    groupNum: number;
    createTime: string;
}



// --------------------------学生---------------------------

//  可编辑表格
interface StudentEditableCellProps {
    title: React.ReactNode;
    editable: boolean;
    children: React.ReactNode;
    dataIndex: keyof StudentItem;
    record: StudentItem;
    handleSave: (record: StudentItem) => void;
    filterOption?: any;
}
// 可编辑表格
interface StudentItem {
    key: string;
    stuId: string;
    name: string;
    stuGroup: string;
    stuState: number;
    createTime: string;
    updateTime: string;
}
// 可编辑表格
interface StudentEditableRowProps {
    index: number;
}
// 可编辑表格
interface StudentDataType {
    key: React.Key;
    stuId: string;
    name: string;
    stuGroup: string;
    stuState: number;
    createTime: string;
    updateTime: string;
}

// --------------------------学生考勤数据类型---------------------------
interface StudentsAttendancesDataType {
    key: React.Key;
    stuId: string;
    stuName: string;
    attendanceType:number;
    attendanceStatus:number;
    attendanceTime: string;
}