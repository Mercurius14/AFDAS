// 路由配置
import { defineConfig } from "umi";

export default defineConfig({
  routes: [
    { path: '/', redirect: '/login' }, // 将所有未匹配的路径重定向到登录页
    { path: '/login', component: '@/pages/login/index' },
    { path: '/student', component: '@/pages/student/index' },
    { path: '/admin', component: '@/pages/admin/index' },
    { path: '*', redirect: '/login' }, // 将所有未匹配的路径重定向到登录页
  ],
  npmClient: 'npm',

});
